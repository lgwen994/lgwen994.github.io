import styled from "@emotion/styled";

export const HeroWrapper = styled.section`
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 90px 0 50px;
    text-align: center;
`;
