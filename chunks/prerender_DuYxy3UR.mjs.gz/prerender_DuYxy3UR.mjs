import { jsx, jsxs } from 'react/jsx-runtime';
import React, { useEffect, useState, useRef, Component, useMemo } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { c as createAstro, a as createComponent, r as renderTemplate, b as addAttribute, d as renderComponent, e as renderHead, f as renderSlot, m as maybeRenderHead } from './astro_C-9UdQ9D.mjs';
import 'kleur/colors';
import 'html-escaper';
import styled from '@emotion/styled';
import { useForm } from 'react-hook-form';
import { z, ZodError } from 'zod';
import axios from 'axios';
import { css, keyframes, Global } from '@emotion/react';
import 'clsx';
import react from '@vitejs/plugin-react';
import { version } from 'react-dom';
import CompressionPlugin from 'vite-plugin-compression';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { EnumChangefreq, SitemapAndIndexStream, SitemapStream } from 'sitemap';
import { createWriteStream } from 'fs';
import { resolve, normalize } from 'path';
import { Readable, pipeline } from 'stream';
import { promisify } from 'util';
import { mkdir } from 'fs/promises';
import replace from 'stream-replace-string';
import { Autoplay } from 'swiper/modules';
import { Swiper, SwiperSlide } from 'swiper/react';
/* empty css                         */

if (typeof process !== "undefined") {
  let proc = process;
  if ("argv" in proc && Array.isArray(proc.argv)) {
    if (proc.argv.includes("--verbose")) ; else if (proc.argv.includes("--silent")) ; else ;
  }
}

const Breakpoints = {
  base: 0,
  sm: 576,
  md: 768,
  lg: 992,
  xl: 1200,
  xxl: 1440,
  xxxl: 1920
};
const MediaQuery = {
  /**
   *
   * @param breakpoint MediaQuery.min("md")
   * @returns @media (min-width: 768px)
   */
  min: (breakpoint) => `@media (min-width: ${Breakpoints[breakpoint]}px)`,
  /**
   *
   * @param breakpoint MediaQuery.max("lg")
   * @returns @media (max-width: 991px)
   */
  max: (breakpoint) => `@media (max-width: ${Breakpoints[breakpoint]}px)`,
  /**
   *
   * @param minBreakpoint MediaQuery.between("md", "lg")
   * @returns @media (min-width: 768px) and (max-width: 991px)
   */
  between: (minBreakpoint, maxBreakpoint) => `@media (min-width: ${Breakpoints[minBreakpoint]}px) and (max-width: ${Breakpoints[maxBreakpoint]}px)`
};

const StyledContainer = styled.div`
    margin: 0 auto;
    padding: 0 20px;
    width: 100%;

    max-width: 540px;

    ${MediaQuery.between("md", "lg")} {
        max-width: 720px;
    }

    ${MediaQuery.between("lg", "xl")} {
        max-width: 960px;
    }

    ${MediaQuery.between("xl", "xxl")} {
        max-width: 1140px;
    }

    ${MediaQuery.min("xxl")} {
        max-width: 1320px;
    }
`;

const Container = ({ children, ...rest }) => {
  return /* @__PURE__ */ jsx(StyledContainer, { ...rest, children });
};

const ThemeVar = css`
    :root {
        --primary: ${"#FFFFFF" /* primary */};
        --secondary: ${"#20222e" /* secondary */};
        --tertiary: ${"#5267ee" /* tertiary */};

        --bg-element: ${"#FFFFFF" /* bgElement */};
        --text-default: ${"#101118" /* textDefault */};
        --text-secondary: ${"#2f3561" /* textSecondary */};
    }
`;
const Theme = {
  primary: "var(--primary)",
  secondary: "var(--secondary)",
  tertiary: "var(--tertiary)",
  bgElement: "var(--bg-element)",
  textDefault: "var(--text-default)",
  textSecondary: "var(--text-secondary)"
};

const ContentSectionStyled = styled.section`
    padding: 100px 0;

    ${MediaQuery.max("lg")} {
        padding: 60px 0;
    }
`;
const ContentSectionWrapper = styled.div`
    text-align: center;

    h3,
    h4,
    h5 {
        margin-bottom: 70px;
        font-weight: 200;
    }

    figure {
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;

        position: relative;

        &::before {
            content: "";
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100%;
            height: 100%;
            background: linear-gradient(
                0deg,
                ${Theme.primary} 0%,
                ${Theme.tertiary} 100%
            );

            filter: blur(100px);
            opacity: 0.7;
            z-index: -1;
        }

        &,
        img {
            border-radius: 10px;

            width: 100%;
            height: auto;
            object-fit: cover;
            max-width: 970px;
            margin: 0 auto;
        }
    }
`;

const ContentSection = ({
  children,
  ...rest
}) => {
  if (!children)
    return null;
  return /* @__PURE__ */ jsx(ContentSectionStyled, { ...rest, children: /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsx(ContentSectionWrapper, { children }) }) });
};

const RobotoBlack = "/_astro/Roboto-Black.tBYbbWl-.woff2";

const RobotoBlackItalic = "/_astro/Roboto-BlackItalic.CxCOE_MU.woff2";

const RobotoBold = "/_astro/Roboto-Bold.OBUL28o9.woff2";

const RobotoBoldItalic = "/_astro/Roboto-BoldItalic.Bbs8lVH2.woff2";

const RobotoItalic = "/_astro/Roboto-Italic.0KLjOP-5.woff2";

const RobotoLight = "/_astro/Roboto-Light.-TzFADkf.woff2";

const RobotoLightItalic = "/_astro/Roboto-LightItalic.DuFP9W7P.woff2";

const RobotoMedium = "/_astro/Roboto-Medium.DRylU_ql.woff2";

const RobotoMediumItalic = "/_astro/Roboto-MediumItalic.CPqftbAj.woff2";

const RobotoRegular = "/_astro/Roboto-Regular.CjbfJjO0.woff2";

const RobotoThin = "/_astro/Roboto-Thin.Df4ydPom.woff2";

const RobotoThinItalic = "/_astro/Roboto-ThinItalic.CI9JpB2v.woff2";

var Fonts = /* @__PURE__ */ ((Fonts2) => {
  Fonts2["primary"] = `"Roboto", sans-serif`;
  return Fonts2;
})(Fonts || {});
const FontFace = css`
    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 100;
        src: url(${RobotoThin}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 300;
        src: url(${RobotoLight}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 400;
        src: url(${RobotoRegular}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 500;
        src: url(${RobotoMedium}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 700;
        src: url(${RobotoBold}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 900;
        src: url(${RobotoBlack}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    // italic
    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 100;
        src: url(${RobotoThinItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }
    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 300;
        src: url(${RobotoLightItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 400;
        src: url(${RobotoItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 500;
        src: url(${RobotoMediumItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 700;
        src: url(${RobotoBoldItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 900;
        src: url(${RobotoBlackItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }
`;

const NormalizeCSS = css`
    ${FontFace};
    ${ThemeVar};

    :root {
        color-scheme: light only;
    }

    body,
    html {
        font-family: ${Fonts.primary};
        font-weight: 400;
        font-size: 16px;
        line-height: 1.5;
    }

    * {
        box-sizing: border-box;
    }

    html {
        line-height: 1.15;
        -webkit-text-size-adjust: 100%;
    }

    body {
        margin: 0;

        color: ${Theme.textDefault};
        background: ${Theme.primary};
    }

    main {
        display: block;
    }

    a {
        background-color: transparent;
    }

    abbr[title] {
        border-bottom: none;
        text-decoration: underline;
        text-decoration: underline dotted;
    }

    img {
        border-style: none;
        object-fit: cover;
    }

    button,
    input,
    optgroup,
    select,
    textarea {
        font-family: inherit; /* 1 */
        font-size: 100%; /* 1 */
        line-height: 1.15; /* 1 */
        margin: 0; /* 2 */
    }

    button,
    [type="button"],
    [type="reset"],
    [type="submit"] {
        -webkit-appearance: button;
    }

    button::-moz-focus-inner,
    [type="button"]::-moz-focus-inner,
    [type="reset"]::-moz-focus-inner,
    [type="submit"]::-moz-focus-inner {
        border-style: none;
        padding: 0;
    }

    button {
        padding: 0;
    }

    figure {
        margin: 0;
        line-height: 0;
    }

    strong {
        font-weight: 700;
    }

    a {
        text-decoration: none;
        color: inherit;
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
        margin: 0 0 30px;

        &:last-child {
            margin: 0;
        }
    }

    h1 {
        font-size: 50px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 40px;
        }
    }

    h2 {
        font-size: 45px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 35px;
        }
    }

    h3 {
        font-size: 35px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 30px;
        }
    }

    h4 {
        font-size: 25px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 25px;
        }
    }

    h5 {
        font-size: 20px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 20px;
        }
    }

    h6 {
        font-size: 18px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 15px;
        }
    }

    p {
        margin: 0 0 10px;
        font-size: 16px;
        line-height: 25px;
        letter-spacing: 1px;
        color: ${Theme.textSecondary};

        &:last-child {
            margin: 0;
        }
    }

    b {
        color: ${Theme.tertiary};
    }
`;

const HeroImg = new Proxy({"src":"/_astro/hero-img.DZAO80zZ.webp","width":1024,"height":683,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/hero-img.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/hero-img.webp");
							return target[name];
						}
					});

const Chart = new Proxy({"src":"/_astro/chart.ByZTC857.webp","width":600,"height":297,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/chart.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/chart.webp");
							return target[name];
						}
					});

const Logo$2 = new Proxy({"src":"/_astro/logo.CIy3CyIk.webp","width":1500,"height":643,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/logo.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/logo.webp");
							return target[name];
						}
					});

const PreviewPng = new Proxy({"src":"/_astro/preview.DQNpCrLA.webp","width":1458,"height":635,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/preview.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/preview.webp");
							return target[name];
						}
					});

const AqImg = new Proxy({"src":"/_astro/aq-img.CkmGmQhM.webp","width":2448,"height":2447,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/aq-img.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/aq-img.webp");
							return target[name];
						}
					});

const Banks = new Proxy({"src":"/_astro/banks.BGVg9tUC.webp","width":2481,"height":3508,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/banks.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/banks.webp");
							return target[name];
						}
					});

const BridgeLoans = new Proxy({"src":"/_astro/bridge-loans.DkQ4Cp4V.png","width":1000,"height":666,"format":"jpg","orientation":1}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/bridge-loans.png";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/bridge-loans.png");
							return target[name];
						}
					});

const ConstructionLoan = new Proxy({"src":"/_astro/construction-loan.ULbqefZ7.png","width":2560,"height":1713,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/construction-loan.png";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/construction-loan.png");
							return target[name];
						}
					});

const FirstHomeBuyer = new Proxy({"src":"/_astro/first-home-buyer.D3i4yHZu.png","width":1820,"height":1213,"format":"jpg","orientation":1}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/first-home-buyer.png";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/first-home-buyer.png");
							return target[name];
						}
					});

const Refinance = new Proxy({"src":"/_astro/refinance.H4Dfbxfu.png","width":780,"height":500,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/refinance.png";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/refinance.png");
							return target[name];
						}
					});

const Investment = new Proxy({"src":"/_astro/investment-property.DNPB_pjC.png","width":1254,"height":836,"format":"jpg","orientation":1}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/investment-property.png";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/investment-property.png");
							return target[name];
						}
					});

const SplitLoan = new Proxy({"src":"/_astro/split-loan.oTlKbW9s.png","width":1024,"height":680,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/split-loan.png";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/split-loan.png");
							return target[name];
						}
					});

const Referral = new Proxy({"src":"/_astro/referral.DtRc6TbZ.png","width":266,"height":190,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/referral.png";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/images/referral.png");
							return target[name];
						}
					});

const images = {
  preview: PreviewPng,
  heroImg: HeroImg,
  chart: Chart,
  logo: Logo$2,
  aqImg: AqImg,
  banks: Banks,
  bridgeLoans: BridgeLoans,
  constructionLoan: ConstructionLoan,
  firstHomeBuyer: FirstHomeBuyer,
  refinance: Refinance,
  investment: Investment,
  splitLoan: SplitLoan,
  referral: Referral
};
const Image = ({
  alt,
  srcLocal,
  height,
  width,
  src,
  loading,
  ...rest
}) => {
  if (!srcLocal && !src) {
    throw new Error("srcLocal or src is required");
  }
  const image = srcLocal ? images[srcLocal] : { src, width, height };
  return /* @__PURE__ */ jsx(
    "img",
    {
      src: image.src,
      alt,
      width: width ? width : image.width,
      height: height ? height : image.height,
      loading,
      ...rest
    }
  );
};

const LogoStyled = styled.div`
    position: relative;
    z-index: 3;

    a {
        font-size: 35px;
        line-height: 30px;
        font-weight: 700;
        display: inline-flex;
        position: relative;

        span {
            &:after {
                content: "";
                position: absolute;
                bottom: -5px;
                left: 0;
                width: 25%;
                height: 3px;
                background-color: ${Theme.primary};
                z-index: 1;
                transition: width 0.2s linear;
            }
        }

        &:hover span:after {
            width: 100%;
        }

        img {
            height: 63px;
            width: 150px;
            object-fit: contain;
        }
    }
`;

const Logo$1 = () => {
  return /* @__PURE__ */ jsx(LogoStyled, { children: /* @__PURE__ */ jsx("a", { href: "/", children: /* @__PURE__ */ jsx(Image, { srcLocal: "logo", alt: "logo" }) }) });
};

const HeaderAnimationKeyframe = keyframes`
    from {
        transform: translateY(-50px);
        opacity: 0.01;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
`;
const HeaderStyled = styled.header`
    width: 100%;

    background: ${Theme.bgElement};

    padding: 20px 0;

    display: flex;

    justify-content: space-between;
    align-items: center;

    gap: 40px;

    position: sticky;
    top: 0;
    left: 0;
    z-index: 10;

    box-shadow: 0 0 10px rgb(123 123 123 / 10%);

    animation: ${HeaderAnimationKeyframe} 1s;
`;
const ContainerStyled$1 = styled(Container)`
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 40px;
`;

const SocialsStyled = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 20px;

    margin: 20px 0 0;
`;
const SocialsList = styled.ul`
    display: flex;
    gap: 10px;
    list-style-type: none;
    align-items: center;
    justify-content: center;
    padding: 0;
    margin: 0;
`;
const SocialsListItem = styled.li`
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;

    cursor: pointer;
    transition: 0.3s;
    opacity: 0.5;

    &:hover {
        opacity: 1;
    }

    &:not(:last-of-type) {
        &:after {
            content: "";
            display: block;
            width: 1px;
            height: 20px;
            background-color: ${Theme.textSecondary};
            margin: 0 10px;
        }
    }
`;
const SocialsLink = styled.a`
    text-decoration: none;
    color: inherit;

    img {
        width: 20px;
        height: 20px;
        aspect-ratio: 20/20;
        object-fit: contain;
    }
`;

const IconFacebook = new Proxy({"src":"/_astro/icon-facebook.B6g6NxN2.svg","width":15,"height":32,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-facebook.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-facebook.svg");
							return target[name];
						}
					});

const IconInstagram = new Proxy({"src":"/_astro/icon-instagram.D1SS_iOG.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-instagram.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-instagram.svg");
							return target[name];
						}
					});

const IconTwitter = new Proxy({"src":"/_astro/icon-twitter.Q9o_GAoy.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-twitter.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-twitter.svg");
							return target[name];
						}
					});

const IconLinkedIn = new Proxy({"src":"/_astro/icon-linkedin.siGonwwC.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-linkedin.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-linkedin.svg");
							return target[name];
						}
					});

const IconArrowDown = new Proxy({"src":"/_astro/icon-arrow-down.C0vMD__j.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-arrow-down.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-arrow-down.svg");
							return target[name];
						}
					});

const IconArrowCircle = new Proxy({"src":"/_astro/icon-arrow-circle.BnhBksj8.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-arrow-circle.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-arrow-circle.svg");
							return target[name];
						}
					});

const IconAstro = new Proxy({"src":"/_astro/icon-astro.C8zxrBYM.svg","width":460,"height":160,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-astro.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-astro.svg");
							return target[name];
						}
					});

const IconSplitLoan = new Proxy({"src":"/_astro/icon-split-loan.BMYnhWMe.svg","width":302,"height":225,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-split-loan.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-split-loan.svg");
							return target[name];
						}
					});

const IconBozinoff = new Proxy({"src":"/_astro/icon-bozinoff.5AjmqtyW.svg","width":2000,"height":857,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-bozinoff.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/static/icons/icon-bozinoff.svg");
							return target[name];
						}
					});

const icons = {
  arrowDown: IconArrowDown,
  arrowCircle: IconArrowCircle,
  facebook: IconFacebook,
  instagram: IconInstagram,
  twitter: IconTwitter,
  linkedin: IconLinkedIn,
  astro: IconAstro,
  splitLoan: IconSplitLoan,
  bozinoff: IconBozinoff
};
const Icon = ({ alt, iconData, ...rest }) => {
  const icon = icons[iconData];
  return /* @__PURE__ */ jsx(
    "img",
    {
      src: icon.src,
      alt,
      width: icon.width,
      height: icon.height,
      "data-icon": "true",
      ...rest
    }
  );
};

const Socials = ({ ...rest }) => {
  return /* @__PURE__ */ jsx(SocialsStyled, { ...rest, children: /* @__PURE__ */ jsxs(SocialsList, { children: [
    /* @__PURE__ */ jsx(SocialsListItem, { children: /* @__PURE__ */ jsx(
      SocialsLink,
      {
        href: "https://www.facebook.com",
        target: "_blank",
        rel: "noreferrer",
        children: /* @__PURE__ */ jsx(Icon, { iconData: "facebook", alt: "facebook" })
      }
    ) }),
    /* @__PURE__ */ jsx(SocialsListItem, { children: /* @__PURE__ */ jsx(
      SocialsLink,
      {
        href: "https://www.linkedin.com",
        target: "_blank",
        rel: "noreferrer",
        children: /* @__PURE__ */ jsx(Icon, { iconData: "linkedin", alt: "linkedin" })
      }
    ) })
  ] }) });
};

const NavigationStyled = styled.div`
    display: flex;
    gap: 50px;

    ${MediaQuery.max("xl")} {
        gap: 20px;
    }
`;
const NavigationListWrapper = styled.nav`
    display: flex;
    align-items: center;
    justify-content: center;

    ${MediaQuery.max("lg")} {
        position: fixed;
        top: 0;
        right: -100%;

        background: ${Theme.bgElement};
        height: 100vh;
        z-index: 2;
        transform: translateX(100%);
        transition: transform 0.3s linear, right 0.7s;
        padding-top: 85px;

        width: clamp(300px, 80%, 300px);

        ${({ $isOpen }) => $isOpen && css`
                right: 0;
                transform: translateX(0);
            `};
    }
`;
const NavigationList = styled.ul`
    padding: 0;
    margin: 0;
    list-style-type: none;
    display: flex;

    ${MediaQuery.min("lg")} {
        gap: 20px;
        align-items: center;
        justify-content: center;
    }

    ${MediaQuery.max("lg")} {
        gap: 10px;
        padding: 20px 10px 53px;
        overflow: auto;
        width: 100%;
        height: 100%;

        flex-direction: column;
        justify-content: flex-start;
        align-items: flex-start;
    }

    > li a {
        text-decoration: none;
        color: ${Theme.textDefault};
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        line-height: 18px;
        padding: 10px;
        border-radius: 5px;
        background-color: transparent;
        cursor: pointer;
        transition: background-color 0.2s linear;

        ${MediaQuery.max("lg")} {
            padding: 10px 20px;
        }

        &:hover {
            background-color: ${Theme.tertiary};
            color: ${Theme.primary};
        }

        &.active:not(:hover) {
            background-color: ${Theme.tertiary};
            color: ${Theme.primary};
        }
        img {
            margin: 0 15px 0 0;

            max-width: 30px;
            max-height: 30px;

            ${MediaQuery.max("xl")} {
                margin: 0 10px 0 0;
            }
        }
    }
`;
styled(Socials)`
    position: absolute;
    bottom: 0;
    background: ${Theme.bgElement};
    width: 100%;
    padding: 10px 0;
    margin: 0;
    left: 0;

    li {
        opacity: 1;
    }

    ${MediaQuery.min("lg")} {
        display: none;
    }
`;

const HamburgerMenuButton = styled.button`
    position: relative;
    z-index: 3;

    border: 1px solid ${Theme.tertiary};
    border-radius: 50%;
    background: ${Theme.bgElement};
    cursor: pointer;
    transition: background 0.3s, border-color 0.3s, color 0.3s;

    width: 45px;
    height: 45px;

    ${MediaQuery.min("lg")} {
        display: none;
    }
`;
const HamburgerMenuButtonLine = styled.span`
    background: ${Theme.tertiary};
    position: absolute;
    left: 50%;
    display: block;
    transform: translate(-50%, -50%);
    transition: transform 0.3s, background 0.3s, top 0.3s;
    pointer-events: none;

    width: 50%;
    height: 3px;

    ${MediaQuery.max("lg")} {
        height: 2px;
    }

    ${({ $open }) => $open ? css`
                  transform: translate(-50%, -50%) rotate(45deg);
                  top: 50%;
              ` : css`
                  top: calc(50% - 4px);
              `}

    &:not(:first-of-type) {
        ${({ $open }) => $open ? css`
                      transform: translate(-49%, -50%) rotate(-45deg);
                      top: 50%;
                  ` : css`
                      top: calc(50% + 4px);
                  `}
    }
`;

const Hamburger = ({ state }) => {
  const { open, setOpen } = state;
  const handleMenu = () => {
    setOpen(!open);
  };
  const handleClickOutside = (e) => {
    const target = e.target;
    if (!target.closest("nav") && open && target.tagName !== "BUTTON") {
      setOpen(false);
    }
  };
  useEffect(() => {
    if (!open)
      return;
    document.addEventListener("click", handleClickOutside);
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, [open]);
  return /* @__PURE__ */ jsxs(
    HamburgerMenuButton,
    {
      $open: open,
      onClick: handleMenu,
      "aria-label": "Menu",
      "aria-expanded": open,
      role: "button",
      tabIndex: 0,
      children: [
        /* @__PURE__ */ jsx(HamburgerMenuButtonLine, { $open: open }),
        /* @__PURE__ */ jsx(HamburgerMenuButtonLine, { $open: open })
      ]
    }
  );
};

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeLink, setActiveLink] = useState("");
  useEffect(() => {
    setActiveLink(window.location.pathname);
    const handlePopState = () => {
      setActiveLink(window.location.pathname);
    };
    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);
  const handleNavigation = (path) => {
    setActiveLink(path);
    setIsOpen(false);
  };
  const navItems = [
    { path: "/", label: "Home" },
    { path: "/about", label: "About Me" },
    { path: "/offers", label: "Our offers" },
    { path: "/privacy", label: "Privacy Policy" },
    { path: "/contact", label: "Contact" }
  ];
  return /* @__PURE__ */ jsxs(NavigationStyled, { children: [
    /* @__PURE__ */ jsx(NavigationListWrapper, { $isOpen: isOpen, children: /* @__PURE__ */ jsx(NavigationList, { children: navItems.map((item) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
      "a",
      {
        href: item.path,
        className: activeLink === item.path ? "active" : "",
        onClick: () => handleNavigation(item.path),
        children: item.label
      }
    ) }, item.path)) }) }),
    /* @__PURE__ */ jsx(
      Hamburger,
      {
        state: {
          open: isOpen,
          setOpen: setIsOpen
        }
      }
    )
  ] });
};

const Header = () => {
  return /* @__PURE__ */ jsx(HeaderStyled, { children: /* @__PURE__ */ jsxs(ContainerStyled$1, { children: [
    /* @__PURE__ */ jsx(Logo$1, {}),
    /* @__PURE__ */ jsx(Navigation, {})
  ] }) });
};

const FooterStyled = styled.footer`
    width: 100%;

    background: ${Theme.bgElement};

    box-shadow: 0 0 10px rgb(123 123 123 / 10%);
    padding: 0 0 50px;
    margin-top: 200px;

    ${MediaQuery.max("lg")} {
        margin-top: 100px;
    }
`;
const FooterContainer = styled.div`
    display: flex;
    justify-content: space-between;

    ${MediaQuery.max("lg")} {
        flex-direction: column;
        gap: 20px;
        justify-content: center;
        align-items: center;
    }
`;
const FooterContent = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 20px;

    ${MediaQuery.max("lg")} {
        flex-direction: column;
        text-align: center;
    }

    p {
        margin: 0;
    }
`;

const FormStyled = styled.form`
    padding: 30px;
    background: ${Theme.bgElement};
    border-radius: 10px;
    box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);
    width: 100%;

    h2 {
        font-size: 30px;
        line-height: 36px;
        font-weight: 300;
        margin-bottom: 10px;

        ${MediaQuery.max("lg")} {
            font-size: 20px;
            line-height: 25px;
        }
    }

    p {
        opacity: 0.8;

        ${MediaQuery.max("lg")} {
            font-size: 14px;
            line-height: 16px;
        }
    }
`;

styled.div`
    background: ${Theme.bgElement};
    transform: translateY(-50%);

    ${MediaQuery.max("lg")} {
        transform: translateY(-20%);
    }
`;
styled.div``;
styled(FormStyled)``;
styled.div`
    display: grid;
    grid-template-columns: 80% 20%;
    gap: 30px;
    align-items: flex-start;

    ${MediaQuery.max("lg")} {
        grid-template-columns: 1fr;
        gap: 0;
    }
`;
styled.h2`
    padding: 20px;
    max-width: 800px;
    margin: 0 auto !important;
    box-shadow: 0 0 30px ${Theme.tertiary};

    ${MediaQuery.max("lg")} {
        font-size: 25px;
        line-height: 30px;
        max-width: 400px;
    }
`;

const defaultInputStyles = css`
    padding: 10px 0;
    border: none;
    width: 100%;
    margin-bottom: 10px;
    box-sizing: border-box;
    background: transparent;
    border-bottom: 1px solid ${Theme.textSecondary};
    transition: border-color 0.3s;
    letter-spacing: 1px;
    color: ${Theme.textDefault};
    margin: 30px 0;

    ${MediaQuery.max("lg")} {
        margin-bottom: 0;
    }

    &:focus,
    &:active {
        outline: none;
        border-color: ${Theme.tertiary};
    }

    &::placeholder {
        color: ${Theme.textSecondary};
    }
`;
const InputWrapper = styled.div``;
const InputStyled = styled.input`
    ${defaultInputStyles}
`;
const InputTextAreaStyled = styled.textarea`
    ${defaultInputStyles};

    resize: none;
    min-height: 90px;
`;

const Input = ({
  placeholder,
  type,
  register,
  error,
  ...rest
}) => {
  const InputComponent = type === "textarea" ? InputTextAreaStyled : InputStyled;
  return /* @__PURE__ */ jsxs(InputWrapper, { children: [
    /* @__PURE__ */ jsx(InputComponent, { placeholder, ...register, ...rest }),
    error && /* @__PURE__ */ jsx("p", { children: error })
  ] });
};

const ButtonWrapper = styled.div`
    display: flex;
    justify-content: ${({ $align }) => $align || "flex-start"};
    margin-top: 20px;
`;
const ButtonLink = styled.a`
    text-transform: uppercase;
    transition: 0.3s;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
    text-align: center;

    ${({ $variant }) => $variant === "primary" && PrimaryVariant};
    ${({ $variant }) => $variant === "secondary" && SecondaryVariant};
`;
const Button$1 = ButtonLink.withComponent("button");
const PrimaryVariant = css`
    padding: 12px 40px;
    min-width: 150px;
    border: 1.5px solid ${Theme.textDefault};
    font-size: 16px;
    line-height: 20px;
    letter-spacing: 1px;
    font-weight: 500;
    border-radius: 50px;
    background: transparent;
    color: ${Theme.textDefault};

    &:hover {
        background: ${Theme.textDefault};
        color: ${Theme.primary};
    }
`;
const SecondaryVariant = css`
    padding: 12px 40px;
    min-width: 150px;
    border: 1.5px solid ${Theme.tertiary};
    font-size: 16px;
    line-height: 20px;
    letter-spacing: 1px;
    font-weight: 500;
    border-radius: 50px;
    background: ${Theme.tertiary};
    color: ${Theme.primary};

    &:hover {
        background: transparent;
        color: ${Theme.tertiary};
    }
`;

const Button = ({
  link,
  target,
  children,
  align,
  variant = "primary",
  asButton,
  type,
  ...rest
}) => {
  const ButtonComponent = asButton ? Button$1 : ButtonLink;
  return /* @__PURE__ */ jsx(ButtonWrapper, { $align: align, children: /* @__PURE__ */ jsx(
    ButtonComponent,
    {
      href: link,
      target,
      ...rest,
      $variant: variant,
      children
    }
  ) });
};

const FadeInStyled = styled.div`
    opacity: 0.001;
    transform: translateY(20px);
    transition: opacity 0.5s, transform 0.5s;

    &.visible {
        opacity: 1;
        transform: translateY(0);
    }
`;

const FadeIn = ({ children, delay }) => {
  const elementRef = useRef(null);
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          } else {
            entry.target.classList.remove("visible");
          }
        });
      },
      {
        root: null,
        rootMargin: "-50px",
        threshold: 0.1
      }
    );
    if (elementRef.current) {
      observer.observe(elementRef.current);
    }
    return () => {
      if (elementRef.current) {
        observer.unobserve(elementRef.current);
      }
    };
  }, []);
  return /* @__PURE__ */ jsx(FadeInStyled, { ref: elementRef, children });
};

const Footer = () => {
  return /* @__PURE__ */ jsx(FooterStyled, { children: /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsxs(FooterContainer, { children: [
    /* @__PURE__ */ jsx(Logo$1, {}),
    /* @__PURE__ */ jsx(FooterContent, { children: /* @__PURE__ */ jsx("p", { children: "© 2025 All rights reserved by AQ Mortgages Limited, Mihali Enterprises Limited trading as Bozinoff Mortgages" }) }),
    /* @__PURE__ */ jsx(Socials, {})
  ] }) }) });
};

function defineConfig(config) {
  return config;
}

const FAST_REFRESH_PREAMBLE = react.preambleCode;
function getRenderer() {
  return {
    name: "@astrojs/react",
    clientEntrypoint: version.startsWith("18.") ? "@astrojs/react/client.js" : "@astrojs/react/client-v17.js",
    serverEntrypoint: version.startsWith("18.") ? "@astrojs/react/server.js" : "@astrojs/react/server-v17.js"
  };
}
function optionsPlugin(experimentalReactChildren) {
  const virtualModule = "astro:react:opts";
  const virtualModuleId = "\0" + virtualModule;
  return {
    name: "@astrojs/react:opts",
    resolveId(id) {
      if (id === virtualModule) {
        return virtualModuleId;
      }
    },
    load(id) {
      if (id === virtualModuleId) {
        return {
          code: `export default {
						experimentalReactChildren: ${JSON.stringify(experimentalReactChildren)}
					}`
        };
      }
    }
  };
}
function getViteConfiguration({
  include,
  exclude,
  experimentalReactChildren
} = {}) {
  return {
    optimizeDeps: {
      include: [
        version.startsWith("18.") ? "@astrojs/react/client.js" : "@astrojs/react/client-v17.js",
        "react",
        "react/jsx-runtime",
        "react/jsx-dev-runtime",
        "react-dom"
      ],
      exclude: [
        version.startsWith("18.") ? "@astrojs/react/server.js" : "@astrojs/react/server-v17.js"
      ]
    },
    plugins: [react({ include, exclude }), optionsPlugin(!!experimentalReactChildren)],
    resolve: {
      dedupe: ["react", "react-dom", "react-dom/server"]
    },
    ssr: {
      external: version.startsWith("18.") ? ["react-dom/server", "react-dom/client"] : ["react-dom/server.js", "react-dom/client.js"],
      noExternal: [
        // These are all needed to get mui to work.
        "@mui/material",
        "@mui/base",
        "@babel/runtime",
        "redoc",
        "use-immer"
      ]
    }
  };
}
function src_default$1({
  include,
  exclude,
  experimentalReactChildren
} = {}) {
  return {
    name: "@astrojs/react",
    hooks: {
      "astro:config:setup": ({ command, addRenderer, updateConfig, injectScript }) => {
        addRenderer(getRenderer());
        updateConfig({
          vite: getViteConfiguration({ include, exclude, experimentalReactChildren })
        });
        if (command === "dev") {
          const preamble = FAST_REFRESH_PREAMBLE.replace(`__BASE__`, "/");
          injectScript("before-hydration", preamble);
        }
      }
    }
  };
}

function parseI18nUrl(url, defaultLocale, locales, base) {
  if (!url.startsWith(base)) {
    return void 0;
  }
  let s = url.slice(base.length);
  if (!s || s === "/") {
    return { locale: defaultLocale, path: "/" };
  }
  if (s[0] !== "/") {
    s = "/" + s;
  }
  const locale = s.split("/")[1];
  if (locale in locales) {
    let path = s.slice(1 + locale.length);
    if (!path) {
      path = "/";
    }
    return { locale, path };
  }
  return { locale: defaultLocale, path: s };
}

function generateSitemap(pages, finalSiteUrl, opts) {
  const { changefreq, priority, lastmod: lastmodSrc, i18n } = opts ?? {};
  const urls = [...pages];
  urls.sort((a, b) => a.localeCompare(b, "en", { numeric: true }));
  const lastmod = lastmodSrc?.toISOString();
  const { defaultLocale, locales } = i18n ?? {};
  let getI18nLinks;
  if (defaultLocale && locales) {
    getI18nLinks = createGetI18nLinks(urls, defaultLocale, locales, finalSiteUrl);
  }
  const urlData = urls.map((url, i) => ({
    url,
    links: getI18nLinks?.(i),
    lastmod,
    priority,
    changefreq
  }));
  return urlData;
}
function createGetI18nLinks(urls, defaultLocale, locales, finalSiteUrl) {
  const parsedI18nUrls = urls.map((url) => parseI18nUrl(url, defaultLocale, locales, finalSiteUrl));
  const i18nPathToLinksCache = /* @__PURE__ */ new Map();
  return (urlIndex) => {
    const i18nUrl = parsedI18nUrls[urlIndex];
    if (!i18nUrl) {
      return void 0;
    }
    const cached = i18nPathToLinksCache.get(i18nUrl.path);
    if (cached) {
      return cached;
    }
    const links = [];
    for (let i = 0; i < parsedI18nUrls.length; i++) {
      const parsed = parsedI18nUrls[i];
      if (parsed?.path === i18nUrl.path) {
        links.push({
          url: urls[i],
          lang: locales[parsed.locale]
        });
      }
    }
    if (links.length <= 1) {
      return void 0;
    }
    i18nPathToLinksCache.set(i18nUrl.path, links);
    return links;
  };
}

const SITEMAP_CONFIG_DEFAULTS = {
  entryLimit: 45e3
};

const localeKeySchema = z.string().min(1);
const SitemapOptionsSchema = z.object({
  filter: z.function().args(z.string()).returns(z.boolean()).optional(),
  customPages: z.string().url().array().optional(),
  canonicalURL: z.string().url().optional(),
  i18n: z.object({
    defaultLocale: localeKeySchema,
    locales: z.record(
      localeKeySchema,
      z.string().min(2).regex(/^[a-zA-Z\-]+$/gm, {
        message: "Only English alphabet symbols and hyphen allowed"
      })
    )
  }).refine((val) => !val || val.locales[val.defaultLocale], {
    message: "`defaultLocale` must exist in `locales` keys"
  }).optional(),
  entryLimit: z.number().nonnegative().optional().default(SITEMAP_CONFIG_DEFAULTS.entryLimit),
  serialize: z.function().args(z.any()).returns(z.any()).optional(),
  changefreq: z.nativeEnum(EnumChangefreq).optional(),
  lastmod: z.date().optional(),
  priority: z.number().min(0).max(1).optional()
}).strict().default(SITEMAP_CONFIG_DEFAULTS);

const validateOptions = (site, opts) => {
  const result = SitemapOptionsSchema.parse(opts);
  z.object({
    site: z.string().optional(),
    // Astro takes care of `site`: how to validate, transform and refine
    canonicalURL: z.string().optional()
    // `canonicalURL` is already validated in prev step
  }).refine((options) => options.site || options.canonicalURL, {
    message: "Required `site` astro.config option or `canonicalURL` integration option"
  }).parse({
    site,
    canonicalURL: result.canonicalURL
  });
  return result;
};

async function writeSitemap({
  hostname,
  sitemapHostname = hostname,
  sourceData,
  destinationDir,
  limit = 5e4,
  publicBasePath = "./"
}, astroConfig) {
  await mkdir(destinationDir, { recursive: true });
  const sitemapAndIndexStream = new SitemapAndIndexStream({
    limit,
    getSitemapStream: (i) => {
      const sitemapStream = new SitemapStream({
        hostname
      });
      const path = `./sitemap-${i}.xml`;
      const writePath = resolve(destinationDir, path);
      if (!publicBasePath.endsWith("/")) {
        publicBasePath += "/";
      }
      const publicPath = normalize(publicBasePath + path);
      let stream;
      if (astroConfig.trailingSlash === "never" || astroConfig.build.format === "file") {
        const host = hostname.endsWith("/") ? hostname.slice(0, -1) : hostname;
        const searchStr = `<loc>${host}/</loc>`;
        const replaceStr = `<loc>${host}</loc>`;
        stream = sitemapStream.pipe(replace(searchStr, replaceStr)).pipe(createWriteStream(writePath));
      } else {
        stream = sitemapStream.pipe(createWriteStream(writePath));
      }
      return [new URL(publicPath, sitemapHostname).toString(), sitemapStream, stream];
    }
  });
  let src = Readable.from(sourceData);
  const indexPath = resolve(destinationDir, `./sitemap-index.xml`);
  return promisify(pipeline)(src, sitemapAndIndexStream, createWriteStream(indexPath));
}

function formatConfigErrorMessage(err) {
  const errorList = err.issues.map((issue) => ` ${issue.path.join(".")}  ${issue.message + "."}`);
  return errorList.join("\n");
}
const PKG_NAME = "@astrojs/sitemap";
const OUTFILE = "sitemap-index.xml";
const STATUS_CODE_PAGES = /* @__PURE__ */ new Set(["404", "500"]);
function isStatusCodePage(pathname) {
  if (pathname.endsWith("/")) {
    pathname = pathname.slice(0, -1);
  }
  const end = pathname.split("/").pop() ?? "";
  return STATUS_CODE_PAGES.has(end);
}
const createPlugin = (options) => {
  let config;
  return {
    name: PKG_NAME,
    hooks: {
      "astro:config:done": async ({ config: cfg }) => {
        config = cfg;
      },
      "astro:build:done": async ({ dir, routes, pages, logger }) => {
        try {
          if (!config.site) {
            logger.warn(
              "The Sitemap integration requires the `site` astro.config option. Skipping."
            );
            return;
          }
          const opts = validateOptions(config.site, options);
          const { filter, customPages, serialize, entryLimit } = opts;
          let finalSiteUrl;
          if (config.site) {
            finalSiteUrl = new URL(config.base, config.site);
          } else {
            console.warn(
              "The Sitemap integration requires the `site` astro.config option. Skipping."
            );
            return;
          }
          let pageUrls = pages.filter((p) => !isStatusCodePage(p.pathname)).map((p) => {
            if (p.pathname !== "" && !finalSiteUrl.pathname.endsWith("/"))
              finalSiteUrl.pathname += "/";
            if (p.pathname.startsWith("/"))
              p.pathname = p.pathname.slice(1);
            const fullPath = finalSiteUrl.pathname + p.pathname;
            return new URL(fullPath, finalSiteUrl).href;
          });
          let routeUrls = routes.reduce((urls, r) => {
            if (r.type !== "page")
              return urls;
            if (r.pathname) {
              if (isStatusCodePage(r.pathname ?? r.route))
                return urls;
              let fullPath = finalSiteUrl.pathname;
              if (fullPath.endsWith("/"))
                fullPath += r.generate(r.pathname).substring(1);
              else
                fullPath += r.generate(r.pathname);
              let newUrl = new URL(fullPath, finalSiteUrl).href;
              if (config.trailingSlash === "never") {
                urls.push(newUrl);
              } else if (config.build.format === "directory" && !newUrl.endsWith("/")) {
                urls.push(newUrl + "/");
              } else {
                urls.push(newUrl);
              }
            }
            return urls;
          }, []);
          pageUrls = Array.from(/* @__PURE__ */ new Set([...pageUrls, ...routeUrls, ...customPages ?? []]));
          try {
            if (filter) {
              pageUrls = pageUrls.filter(filter);
            }
          } catch (err) {
            logger.error(`Error filtering pages
${err.toString()}`);
            return;
          }
          if (pageUrls.length === 0) {
            logger.warn(`No pages found!
\`${OUTFILE}\` not created.`);
            return;
          }
          let urlData = generateSitemap(pageUrls, finalSiteUrl.href, opts);
          if (serialize) {
            try {
              const serializedUrls = [];
              for (const item of urlData) {
                const serialized = await Promise.resolve(serialize(item));
                if (serialized) {
                  serializedUrls.push(serialized);
                }
              }
              if (serializedUrls.length === 0) {
                logger.warn("No pages found!");
                return;
              }
              urlData = serializedUrls;
            } catch (err) {
              logger.error(`Error serializing pages
${err.toString()}`);
              return;
            }
          }
          const destDir = fileURLToPath(dir);
          await writeSitemap(
            {
              hostname: finalSiteUrl.href,
              destinationDir: destDir,
              publicBasePath: config.base,
              sourceData: urlData,
              limit: entryLimit
            },
            config
          );
          logger.info(`\`${OUTFILE}\` created at \`${path.relative(process.cwd(), destDir)}\``);
        } catch (err) {
          if (err instanceof ZodError) {
            logger.warn(formatConfigErrorMessage(err));
          } else {
            throw err;
          }
        }
      }
    }
  };
};
var src_default = createPlugin;

const siteUrl = "https://agency-aestro-astro.netlify.app";

const date = new Date().toISOString();
// https://astro.build/config
defineConfig({

    site: 'https://lgwen994.github.io',
    base: '/',  
    trailingSlash: 'always', 
    build: {
        format: 'directory',
        assets: '_astro' 
    },
    integrations: [
        src_default$1(),
        src_default({
            serialize(item) {
                // Default values for pages
                item.priority = siteUrl + "/" === item.url ? 1.0 : 0.9;
                item.changefreq = "weekly";
                item.lastmod = date;

                // if you want to exclude a page from the sitemap, do it here
                // if (/exclude-from-sitemap/.test(item.url)) {
                //     return undefined;
                // }

                // if any page needs a different priority, changefreq, or lastmod, uncomment the following lines and adjust as needed
                // if (/test-sitemap/.test(item.url)) {
                //     item.changefreq = "daily";
                //     item.lastmod = date;
                //     item.priority = 0.9;
                // }

                // if you want to change priority of all subpages like "/posts/*", you can use:
                // if (/\/posts\//.test(item.url)) {
                //     item.priority = 0.7;
                // }
                return item;
            },
        }),
    ],
    renderers: ["@astrojs/renderer-react"],
    prerender: true,
    vite: {
        plugins: [CompressionPlugin()],
        base: '/'
    },
    buildOptions: {
        minify: true,
    },
});

const $$Astro$7 = createAstro("https://lgwen994.github.io");
const $$MetaConfig = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$7, $$props, $$slots);
  Astro2.self = $$MetaConfig;
  const { title, description, preview } = Astro2.props;
  const metaData = {
    keywords: "astro.build, astro, static site, react, webiste templates, website creation, react templates, next.js templates, astro templates, custom website, custom website templates",
    default: {
      url: siteUrl,
      type: "website",
      title,
      description,
      image: preview
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      image: preview,
      domain: siteUrl,
      url: siteUrl
    }
  };
  return renderTemplate`<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><!-- icons --><link rel="icon" type="image/x-icon" href="/favicon.ico"><link rel="apple-touch-icon" sizes="48x48" href="/favicon.ico"><!-- Other meta important things --><meta name="generator"${addAttribute(Astro2.generator, "content")}><meta name="description"${addAttribute(description, "content")}><meta name="color-scheme" content="light only"><meta name="keywords"${addAttribute(metaData.keywords, "content")}><meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1"><!-- default ones --><meta property="url"${addAttribute(metaData.default.url, "content")}><meta property="type"${addAttribute(metaData.default.type, "content")}><meta property="title"${addAttribute(metaData.default.title, "content")}><meta property="description"${addAttribute(metaData.default.description, "content")}><meta property="image"${addAttribute(metaData.default.image, "content")}><!-- open graph ones --><meta property="og:url"${addAttribute(metaData.default.url, "content")}><meta property="og:type"${addAttribute(metaData.default.type, "content")}><meta property="og:title"${addAttribute(metaData.default.title, "content")}><meta property="og:description"${addAttribute(metaData.default.description, "content")}><meta property="og:image"${addAttribute(metaData.default.image, "content")}><!-- twitter ones --><meta name="twitter:card"${addAttribute(metaData.twitter.card, "content")}><meta name="twitter:title"${addAttribute(metaData.twitter.title, "content")}><meta name="twitter:description"${addAttribute(metaData.twitter.description, "content")}><meta name="twitter:image"${addAttribute(metaData.twitter.image, "content")}><meta property="twitter:domain"${addAttribute(metaData.twitter.domain, "content")}><meta property="twitter:url"${addAttribute(metaData.twitter.url, "content")}>`;
}, "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/layouts/MetaConfig.astro", void 0);

const $$Astro$6 = createAstro("https://lgwen994.github.io");
const $$Layout = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$Layout;
  const { title, description, overwritePreview } = Astro2.props;
  return renderTemplate`<html lang="en"> <head>${renderComponent($$result, "MetaConfig", $$MetaConfig, { "title": title, "description": description, "preview": overwritePreview ? overwritePreview : PreviewPng.src })}<title>${title}</title>${renderComponent($$result, "Global", Global, { "styles": NormalizeCSS })}${renderHead()}</head> <body> ${renderComponent($$result, "Header", Header, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Header", "client:component-export": "Header" })} ${renderSlot($$result, $$slots["default"])} ${renderComponent($$result, "Footer", Footer, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@modules/Footer", "client:component-export": "Footer" })} </body></html>`;
}, "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/layouts/Layout.astro", void 0);

const $$Astro$5 = createAstro("https://lgwen994.github.io");
const $$404 = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$404;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "404 | Page not found", "description": "The page you are looking for might have been removed, had its name changed, or is temporarily unavailable." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "ContentSection", ContentSection, { "style": {
    maxWidth: "600px",
    margin: "0 auto",
    minHeight: "850px",
    textAlign: "center",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center"
  } }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h1>Wooops - Soory! 404</h1> <p>
The page you are looking for might have been removed, had
                    its name changed, or is temporarily unavailable.
</p> ${renderComponent($$result4, "Button", Button, { "variant": "secondary", "link": "/", "align": "center" }, { "default": ($$result5) => renderTemplate`
Go back
` })} ` })} ` })} </main> ` })}`;
}, "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/pages/404.astro", void 0);

const $$file$5 = "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/pages/404.astro";
const $$url$5 = "/404/";

const _404 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$404,
  file: $$file$5,
  url: $$url$5
}, Symbol.toStringTag, { value: 'Module' }));

const BoxOffersStyled = styled.section`
    padding: 90px 0;
`;
const BoxOffersWrapper = styled.div`
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 30px;

    ${MediaQuery.max("lg")} {
        grid-template-columns: repeat(1, 1fr);
    }

    h2 {
        letter-spacing: 2px;
        margin-bottom: 10px;
    }

    h2 {
        font-size: 35px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 30px;
        }
    }
`;

const TextBotStyed = styled.div`
    padding: 30px;
    border-radius: 10px;
    background: ${Theme.bgElement};

    display: flex;
    flex-direction: column;
    justify-content: space-between;
    height: 100%;
    position: relative;

    &::before {
        content: "";
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 100%;
        height: 100%;
        background: linear-gradient(
            0deg,
            ${Theme.tertiary} 100%,
            ${Theme.primary} 0%
        );
        filter: blur(30px);
        opacity: 0.1;
        z-index: -1;
        transition: 0.3s opacity;
    }

    ${(props) => props.$variant === "background-text" && TextBoxBackgroundTextVariant}
`;
const TextBoxLinkStyled = styled(TextBotStyed.withComponent("a"))`
    &:hover {
        &:before {
            opacity: 0.6;
        }

        img[data-icon="true"] {
            transform: translate(10px, -10px) scale(1.1);
        }
    }
`;
const TextBotBgText = styled.span`
    position: absolute;
    top: 0;
    right: 0;
    text-transform: uppercase;

    font-size: 90px;
    line-height: 1;
    font-weight: 900;
    letter-spacing: -7px;
    z-index: 1;
    color: ${Theme.primary};
    opacity: 0.5;

    ${MediaQuery.max("xxl")} {
        font-size: 80px;
    }

    ${MediaQuery.max("xl")} {
        font-size: 60px;
        letter-spacing: -3px;
    }
`;
const TextBotTextWrapper = styled.div`
    position: relative;
    z-index: 2;

    ${MediaQuery.max("md")} {
        max-width: 80%;
    }
`;
const TextBoxBackgroundTextVariant = css`
    position: relative;
    overflow: hidden;
    padding: 20px;

    h2,
    h3,
    h4 {
        margin-bottom: 10px;
        font-size: 25px;
        line-height: 1.2;

        &:after {
            content: none;
        }
    }

    h4,
    p {
        position: relative;
        z-index: 2;
    }

    p {
        line-height: 1.2;
    }
`;
const LinkIconFigure = styled.figure`
    display: flex;
    justify-content: flex-end;
    align-items: flex-end;
    width: 100%;
`;
const LinkIcon = styled(Icon)`
    transition: transform 0.3s;
`;

const TextBox = ({
  children,
  variant,
  bgText,
  boxAsLink,
  ...rest
}) => {
  if (!children)
    return null;
  const TextBoxComponent = boxAsLink ? TextBoxLinkStyled : TextBotStyed;
  return /* @__PURE__ */ jsxs(TextBoxComponent, { $variant: variant, ...rest, children: [
    variant === "background-text" && bgText && /* @__PURE__ */ jsx(TextBotBgText, { children: bgText }),
    /* @__PURE__ */ jsx(
      TextBotTextWrapper,
      {
        dangerouslySetInnerHTML: { __html: children }
      }
    ),
    boxAsLink && /* @__PURE__ */ jsx(LinkIconFigure, { children: /* @__PURE__ */ jsx(LinkIcon, { iconData: "arrowCircle", alt: "arrow" }) })
  ] });
};

const BoxOffers = ({ boxes }) => {
  if (!boxes || boxes.length === 0)
    return null;
  return /* @__PURE__ */ jsx(BoxOffersStyled, { children: /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsx(BoxOffersWrapper, { children: boxes.map((box, index) => {
    return box.content && /* @__PURE__ */ jsx(FadeIn, { delay: `0.` + index, children: /* @__PURE__ */ jsx(
      TextBox,
      {
        boxAsLink: box.asLink,
        href: box.href,
        children: box.content
      }
    ) }, index);
  }) }) }) });
};

const HeroWrapper = styled.section`
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 90px 0 50px;
    text-align: center;
`;

const CenterTextStyled = styled.div`
    width: 100%;

    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;

    max-width: 650px;
    margin: 0 auto;
    position: relative;

    &::before {
        content: "";
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 80%;
        height: 80%;
        background: linear-gradient(
            0deg,
            transparent 0%,
            ${Theme.tertiary} 100%
        );

        filter: blur(100px);
        opacity: 0.3;
        z-index: -1;
    }

    .icon-wrapper {
        margin-top: 50px;
    }
`;

const CenterText = ({ children }) => {
  if (!children)
    return null;
  return /* @__PURE__ */ jsx(CenterTextStyled, { children });
};

const TextImageStyled = styled.div`
    width: 100%;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 50px;
    text-align: left;

    align-items: center;

    ${MediaQuery.max("lg")} {
        grid-template-columns: 1fr;
        text-align: center;
    }

    ${({ $switchPlaces }) => $switchPlaces && css`
            > div:first-of-type {
                order: 2;
            }
        `}
`;
const TextImageFigure = styled.figure`
    width: 100%;
    position: relative;

    &::before {
        content: "";
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 100%;
        height: 100%;
        border-radius: 100%;
        background: linear-gradient(
            0deg,
            ${Theme.tertiary} 100%,
            ${Theme.primary} 0%
        );

        filter: blur(50px);
        opacity: 0.3;
        z-index: -1;
    }
`;
const TextImage$1 = styled(Image)`
    width: 100%;
    margin-bottom: 30px;
    min-height: 450px;

    object-fit: contain;

    ${MediaQuery.max("lg")} {
        min-height: auto;
    }
`;
const TextImageContent = styled.div`
    ${MediaQuery.max("lg")} {
        max-width: 490px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        margin: 0 auto;
    }

    h1 {
        margin-bottom: 20px;
        font-size: 80px;
        line-height: 84px;
        letter-spacing: -1px;

        ${MediaQuery.max("xl")} {
            font-size: 60px;
            line-height: 64px;
        }

        ${MediaQuery.max("sm")} {
            font-size: 50px;
            line-height: 45px;
            letter-spacing: -0.5px;
        }
    }

    p {
        ${MediaQuery.min("lg")} {
            max-width: 560px;
        }
    }
`;
const ButtonsWrapper = styled.div`
    display: flex;

    ${MediaQuery.min("lg")} {
        gap: 30px;
    }

    ${MediaQuery.max("lg")} {
        flex-direction: column;
        align-items: center;
    }
`;

const TextImage = ({
  title,
  paragraph,
  buttons,
  image,
  switchPlaces = false
}) => {
  if (!title && !paragraph && !image) {
    return null;
  }
  const displayImage = image.srcLocal ? /* @__PURE__ */ jsx(
    TextImage$1,
    {
      srcLocal: image.srcLocal,
      alt: image.alt,
      width: image.width,
      height: image.height
    }
  ) : /* @__PURE__ */ jsx(
    TextImage$1,
    {
      src: image.src,
      alt: image.alt,
      width: image.width,
      height: image.height
    }
  );
  return /* @__PURE__ */ jsxs(TextImageStyled, { $switchPlaces: switchPlaces, children: [
    /* @__PURE__ */ jsx(FadeIn, { delay: 0.2, children: /* @__PURE__ */ jsxs(TextImageContent, { children: [
      title && /* @__PURE__ */ jsx("h2", { dangerouslySetInnerHTML: { __html: title } }),
      paragraph && /* @__PURE__ */ jsx("p", { dangerouslySetInnerHTML: { __html: paragraph } }),
      buttons && buttons.length > 0 && /* @__PURE__ */ jsx(ButtonsWrapper, { children: buttons.map((button, index) => {
        return /* @__PURE__ */ jsx(
          Button,
          {
            link: button.link,
            variant: button.variant,
            children: button.text
          },
          index
        );
      }) })
    ] }) }),
    image && /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsx(TextImageFigure, { children: displayImage }) })
  ] });
};

const Hero = ({ heroType, children, content }) => {
  if (!children && !content) {
    return null;
  }
  let HeroTypeOutput;
  switch (heroType) {
    case "center":
      HeroTypeOutput = /* @__PURE__ */ jsx(CenterText, { children });
      break;
    case "textImage":
      HeroTypeOutput = /* @__PURE__ */ jsx(TextImage, { ...content });
      break;
  }
  return /* @__PURE__ */ jsx(HeroWrapper, { children: /* @__PURE__ */ jsx(Container, { children: HeroTypeOutput }) });
};

const $$Astro$4 = createAstro("https://lgwen994.github.io");
const $$About = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$About;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Agency Aestro", "description": "YOUR META DESCRIPTION FOR SEO" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "ContentSection", ContentSection, { "style": {
    maxWidth: "600px",
    margin: "0 auto"
  } }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h1>About Me</h1> <p></p> ` })} ` })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    switchPlaces: true,
    title: ``,
    paragraph: `Yuan (Annie) Qian is a registered Mortgage Adviser in Wellington through NZ Financial Services Group Limited, working in Bozinoff Mortgages. FSP Number FSP1009181.
My passion is helping clients to reach their property and financial freedom by processing and gaining high quality finance approvals and solutions.
I am fluent in English and Mandarin, and can communicate with customers without any obstacles. `,
    image: {
      srcLocal: "aqImg",
      alt: "hero section image",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    title: `About us more`,
    paragraph: `lorem ipsum dolores lorem ipsum dolores lorem ipsum dolores lorem ipsum dolores lorem ipsum dolores lorem ipsum dolores `,
    image: {
      src: "https://picsum.photos/630/400?random=3",
      alt: "hero section image",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Container", Container, {}, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h2>Check our profiles!</h2> ` })} ` })} ${renderComponent($$result2, "BoxOffers", BoxOffers, { "client:load": true, "boxes": [
    {
      asLink: true,
      href: "https://www.facebook.com",
      content: `
                        <h3>Facebook</h3>
                    `
    },
    {
      asLink: true,
      href: "https://www.linkedin.com/c",
      content: `
                        <h3>Linkedin</h3>
                    `
    },
    {
      asLink: true,
      href: "https://www.twitter.com",
      content: `
                        <h3>Twitter</h3>
                    `
    }
  ], "client:component-hydration": "load", "client:component-path": "@modules/BoxOffers", "client:component-export": "BoxOffers" })} </main> ` })}`;
}, "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/pages/about.astro", void 0);

const $$file$4 = "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/pages/about.astro";
const $$url$4 = "/about/";

const about = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$About,
  file: $$file$4,
  url: $$url$4
}, Symbol.toStringTag, { value: 'Module' }));

const ContactStyled = styled.section`
    padding: 100px 0;

    ${MediaQuery.max("lg")} {
        padding: 60px 0;
    }
`;
styled.div`
    max-width: 920px;
    margin: 0 auto;
`;
styled.h2`
    &,
    &:last-child {
        margin-bottom: 90px;
    }
`;
const ContainerStyled = styled(Container)`
    ${MediaQuery.min("xxxl")} {
        max-width: 920px;
    }
`;
const ContactBox = styled.div`
    margin: 40px 0;
`;
const ContactThankYou = styled.h2`
    padding: 20px;
    max-width: 800px;
    margin: 0 auto !important;
    box-shadow: 0 0 30px #bc52ee7a;

    ${MediaQuery.max("lg")} {
        font-size: 25px;
        line-height: 30px;
        max-width: 400px;
    }
`;

class LocationMap extends Component {
  static defaultProps = {
    center: {
      lat: -41.31803827129974,
      lng: 174.79456297182443
    },
    zoom: 18
  };
  render() {
    return (
      // Important! Always set the container height explicitly
      /* @__PURE__ */ jsx("div", { style: { height: "450px", width: "100%" }, children: /* @__PURE__ */ jsx(
        "iframe",
        {
          src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5993.129031253087!2d174.7920309768587!3d-41.318336442343224!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d38afe516f5c693%3A0x8d3620342949483f!2sBozinoff%20Mortgages!5e0!3m2!1sen!2snz!4v1747480496543!5m2!1sen!2snz",
          width: "100%",
          height: "450",
          frameBorder: "0",
          style: { border: "0" },
          allowFullScreen: "",
          "aria-hidden": "false",
          tabIndex: "0",
          title: "Wellington Map"
        }
      ) })
    );
  }
}

const Contact = () => {
  const [emailSend, setEmailSend] = useState(false);
  const schema = z.object({
    name: z.string().min(2, {
      message: "Name should be at least 2 characters"
    }),
    email: z.string().email({
      message: "Please enter a valid email"
    }),
    message: z.string().min(10, {
      message: "Message should be at least 10 characters"
    })
  });
  const contactForm = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      name: "",
      email: "",
      message: ""
    }
  });
  const formSubmit = contactForm.handleSubmit(async (values) => {
    axios.post("https://api.emailjs.com/api/v1.0/email/send", {
      service_id: "service_YOUR_ID",
      template_id: "template_YOur_ID",
      user_id: "your_user_id",
      template_params: {
        name: values.name,
        email: values.email,
        message: values.message
      }
    }).then((res) => {
      if (res.status === 200) {
        setEmailSend(true);
      }
    });
  });
  return /* @__PURE__ */ jsx(ContactStyled, { children: /* @__PURE__ */ jsxs(ContainerStyled, { children: [
    !emailSend ? /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs(FormStyled, { onSubmit: formSubmit, children: [
      /* @__PURE__ */ jsxs("h2", { children: [
        "Please complete the form below.",
        " ",
        /* @__PURE__ */ jsx("b", { children: "Let's talk!" })
      ] }),
      /* @__PURE__ */ jsx("p", { children: "change API links to your own service to make it work (whole script is setup correctly just change API links)" }),
      /* @__PURE__ */ jsx(
        Input,
        {
          type: "text",
          placeholder: "Name *",
          register: contactForm.register("name"),
          error: contactForm.formState.errors.name?.message
        }
      ),
      /* @__PURE__ */ jsx(
        Input,
        {
          type: "email",
          placeholder: "Email *",
          register: contactForm.register("email"),
          error: contactForm.formState.errors.email?.message
        }
      ),
      /* @__PURE__ */ jsx(
        Input,
        {
          type: "text",
          placeholder: "Mobile Number *",
          register: contactForm.register("email"),
          error: contactForm.formState.errors.email?.message
        }
      ),
      /* @__PURE__ */ jsx(
        Input,
        {
          type: "textarea",
          placeholder: "Message *",
          register: contactForm.register("message"),
          error: contactForm.formState.errors.message?.message
        }
      ),
      /* @__PURE__ */ jsx(
        Button,
        {
          asButton: true,
          type: "submit",
          variant: "secondary",
          children: "Submit"
        }
      )
    ] }) }) : /* @__PURE__ */ jsx(ContactThankYou, { children: "Thank you for your message! I will get back to you as soon as possible" }),
    /* @__PURE__ */ jsx(ContactBox, { children: /* @__PURE__ */ jsxs(FadeIn, { delay: 0.2, children: [
      /* @__PURE__ */ jsx("h2", { children: "Send via email" }),
      /* @__PURE__ */ jsx(
        TextBox,
        {
          bgText: "Email",
          boxAsLink: true,
          href: "mailto:youremgail@gmail.com",
          target: "_blank",
          children: `
                            <h3>Click to send email</h3>
                            <p>
                                Feel free to send us an email if you have any
                                questions
                            </p>
                            `
        }
      )
    ] }) }),
    /* @__PURE__ */ jsx(ContactBox, { children: /* @__PURE__ */ jsx(FadeIn, { delay: 0.2, children: /* @__PURE__ */ jsx(LocationMap, {}) }) })
  ] }) });
};

const $$Astro$3 = createAstro("https://lgwen994.github.io");
const $$Contact = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$Contact;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Agency Aestro | Offers", "description": "YOUR META DESCRIPTION FOR SEO" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "center", "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "delay": 0.2, "client:load": true, "client:component-hydration": "load", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h1>Contact us</h1> ` })} ` })} ${renderComponent($$result2, "ContactModule", Contact, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Contact", "client:component-export": "Contact" })} </main> ` })}`;
}, "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/pages/contact.astro", void 0);

const $$file$3 = "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/pages/contact.astro";
const $$url$3 = "/contact/";

const contact = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Contact,
  file: $$file$3,
  url: $$url$3
}, Symbol.toStringTag, { value: 'Module' }));

const $$Astro$2 = createAstro("https://lgwen994.github.io");
const $$Offers = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Offers;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Agency Aestro | Offers", "description": "YOUR META DESCRIPTION FOR SEO" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "center", "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "delay": 0.2, "client:load": true, "client:component-hydration": "load", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h1>What we offer?</h1> <p></p> ` })} ${renderComponent($$result3, "FadeIn", FadeIn, { "delay": 0.3, "client:load": true, "client:component-hydration": "load", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` ${renderComponent($$result4, "Button", Button, { "link": "/contact", "variant": "secondary" }, { "default": ($$result5) => renderTemplate`
Contact us
` })} ` })} ${renderComponent($$result3, "FadeIn", FadeIn, { "client:load": true, "delay": 0.4, "client:component-hydration": "load", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <div class="icon-wrapper"> ${renderComponent($$result4, "Icon", Icon, { "iconData": "arrowDown", "alt": "arrow down icon" })} </div> ` })} ` })} <!-- <LogosSlider client:load /> --> ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    title: `<span id="firsthome">\u2705First Home Buyers</span>`,
    paragraph: `
                <div class="service-section first-home-buyers compact">
                    <h5 class="service-title">Buying your first home? Let me make it easy for you.</h5>
                    
                    <p class="service-intro">I know buying your first home can feel overwhelming. Dealing with agents, lawyers, valuers, banks, and insurance companies is a lot \u2014 but you don't have to do it alone.</p>
                    
                    <div class="benefits-block">
                        <h5 class="section-heading">Here's how I can help:</h5>
                        <ul class="benefits-list">
                            <li class="benefit-item">
                                <span class="check-icon">\u2705</span> I'll arrange pre-approval, so you know exactly how much you can spend.
                            </li>
                            <li class="benefit-item">
                                <span class="check-icon">\u2705</span> I'll support you from offer to settlement \u2014 every step of the way.
                            </li>
                            <li class="benefit-item">
                                <span class="check-icon">\u2705</span> I'll help you choose the right lender and loan structure.
                            </li>
                            <li class="benefit-item">
                                <span class="check-icon">\u2705</span> I'll negotiate a great interest rate and cash contribution for you.
                            </li>
                            <li class="benefit-item">
                                <span class="check-icon">\u2705</span> And best of all \u2014 my service is free when you take a loan with a main bank!
                            </li>
                        </ul>
                    </div>
                    
                    <div class="concerns-block">
                        <h5 class="section-heading">Worried about something?</h5>
                        <ul class="concerns-list">
                            <li class="concern-item">Not sure if you have enough deposit?</li>
                            <li class="concern-item">Concerned about income or credit history?</li>
                            <li class="concern-item">Not a NZ resident yet?</li>
                        </ul>
                        <p class="reassurance">No problem \u2014 I'll answer all your questions and help find the best solution for you.</p>
                    </div>
                    
                    <div class="cta-block">
                        <h5 class="section-heading">Want to chat?</h5>
                        <p class="cta-text">Let's grab a coffee and talk about how I can help you buy your first home.</p>
                        <p class="cta-action">Just enter your details below and I'll be in touch!</p>
                    </div>
                </div>

                <style>
                .first-home-buyers.compact {
                    line-height: 1.4;
                    padding: 1rem;
                }

                .compact .service-title {
                    margin-bottom: 0.5rem;
                    font-size: 1.3rem;
                }

                .compact .service-intro {
                    margin-bottom: 1rem;
                }

                .compact .section-heading {
                    margin: 1rem 0 0.5rem;
                }

                .compact .benefits-list {
                    margin: 0.8rem 0;
                }

                .compact .benefit-item {
                    margin-bottom: 0.5rem;
                    padding-left: 1.5rem;
                }

                .compact .concerns-list {
                    margin: 0.8rem 0;
                }

                .compact .reassurance {
                    margin: 0.8rem 0;
                }

                .compact .cta-text {
                    margin-bottom: 0.3rem;
                }

                .compact .cta-action {
                    margin-top: 0.5rem;
                }
                #firsthome {
                scroll-margin-top: 15vh;
                }
                </style>
                `,
    image: {
      srcLocal: "firstHomeBuyer",
      alt: "hero section image",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    switchPlaces: true,
    title: `<span id="refinancing">\u{1F501}Refinancing & Refixing</span>`,
    paragraph: `
                <div class="service-section refinancing compact">
                    <h5 class="service-title">\u{1F3E1} Thinking About Refinancing? Let's Make It Easy.</h5>
                    
                    <p class="service-intro">Are you on a floating interest rate or is your fixed rate coming up for renewal? Wanting to refinance or top up your home loan for a new car, holiday, or renovation?</p>
                    
                    <div class="benefits-block">
                        <ul class="benefits-list">
                            <li class="benefit-item">
                                <span class="check-icon">\u2705</span> I can help you lock in record low discounted rates \u2013 fast and easy.
                            </li>
                            <li class="benefit-item">
                                <span class="check-icon">\u2705</span> I'll guide you through the process and make sure it's worth your while.
                            </li>
                        </ul>
                    </div>
                    
                    <div class="reasons-block">
                        <h5 class="section-heading">\u{1F4C8} Why Do Refinance?</h5>
                        <p>Many people refinance their mortgage to:</p>
                        <ul class="reasons-list">
                            <li class="reason-item">\u{1F504} Consolidate debt</li>
                            <li class="reason-item">\u{1F6E0}\uFE0F Renovate or invest</li>
                            <li class="reason-item">\u{1F4B0} Access equity in their property</li>
                            <li class="reason-item">\u{1F4C9} Secure a better home loan interest rate</li>
                            <li class="reason-item">\u{1F504} Move between fixed and variable rates</li>
                        </ul>
                    </div>
                    
                    <div class="considerations-block">
                        <h5 class="section-heading">\u{1F914} What Should You Consider?</h5>
                        <p>Before making the move, it's important to weigh the costs vs long-term benefits. I'll help you do the sums. Let's consider:</p>
                        <ul class="considerations-list">
                            <li class="consideration-item">\u2757 Exit or deferred establishment fees on your current loan</li>
                            <li class="consideration-item">\u{1F4B8} Establishment fees on your new loan \u2014 are there any special deals?</li>
                            <li class="consideration-item">\u{1F4C9} What happens to repayments after fixed or honeymoon rates expire?</li>
                            <li class="consideration-item">\u{1F9EE} Whether you have enough equity if you're topping up</li>
                        </ul>
                    </div>
                    
                    <div class="cta-block">
                        <h5 class="section-heading">\u2615 Let's Catch Up</h5>
                        <p class="cta-text">If you'd like to meet for a coffee and talk about how I can help you achieve your goals or reach financial freedom, just enter your details below and I'll be in touch.</p>
                        <p class="cta-action">Refinancing doesn't have to be hard \u2014 I'll make it easy.</p>
                    </div>
                </div>

                <style>
                .refinancing.compact {
                    line-height: 1.4;
                    padding: 1rem;
                }

                .compact .service-title {
                    margin-bottom: 0.5rem;
                    font-size: 1.3rem;
                }

                .compact .service-intro {
                    margin-bottom: 1rem;
                }

                .compact .section-heading {
                    margin: 1rem 0 0.5rem;
                }

                .compact .benefits-list,
                .compact .reasons-list,
                .compact .considerations-list {
                    margin: 0.8rem 0;
                    padding-left: 1rem;
                }

                .compact .benefit-item,
                .compact .reason-item,
                .compact .consideration-item {
                    margin-bottom: 0.5rem;
                    padding-left: 1.5rem;
                }

                .compact .cta-text {
                    margin-bottom: 0.3rem;
                }

                .compact .cta-action {
                    margin-top: 0.5rem;
                    font-weight: 600;
                }
                #refinancing {
                scroll-margin-top: 15vh;
                }
                </style>
                `,
    image: {
      srcLocal: "refinance",
      alt: "hero section image",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    title: `<span id="construction">\u{1F3E1}Construction Loans</span>`,
    paragraph: `<div class="service-section construction-loans compact">
                <h5 class="service-title">\u{1F3E1} Building Your Dream Home? I Can Help!</h5>
                <p class="service-subtitle">Construction Loans & House + Land Packages</p>
                
                <p class="service-intro">Whether you're buying land, building from scratch, or going for a turn-key package \u2014 I'm here to guide you every step of the way.</p>
                
                <div class="loan-types">
                    <div class="loan-block">
                        <h5 class="section-heading">\u{1F528} Construction Loans \u2013 How It Works:</h5>
                        <ul class="benefits-list">
                            <li class="benefit-item">\u2705 Only 10% deposit needed for owner-occupied</li>
                            <li class="benefit-item">\u2705 20% deposit for investors</li>
                            <li class="benefit-item">\u2705 Interest-only repayments during the build</li>
                            <li class="benefit-item">\u2705 Pay interest only on what you've used</li>
                            <li class="benefit-item">\u2705 Turn your plans into reality \u2014 stage by stage</li>
                            <li class="benefit-item">\u2705 I'll help you get all the right paperwork (Sale & Purchase + Fixed Price Build Contract)</li>
                        </ul>
                    </div>
                    
                    <div class="land-block">
                        <h5 class="section-heading">\u{1F4CD} Buying Land Only?</h5>
                        <p>You'll need a minimum 20% deposit \u2014 I can help you get approved.</p>
                    </div>
                    
                    <div class="turnkey-block">
                        <h5 class="section-heading">\u{1F6AA} Turn-Key Homes \u2013 Hassle-Free!</h5>
                        <p>Prefer a ready-to-move-in option?</p>
                        <ul class="benefits-list">
                            <li class="benefit-item">\u2705 Fixed-price, no surprises</li>
                            <li class="benefit-item">\u2705 Just a 10% deposit, balance on completion</li>
                            <li class="benefit-item">\u2705 No loan repayments during the build</li>
                            <li class="benefit-item">\u2705 Pay mortgage only when the home is ready</li>
                            <li class="benefit-item">\u2705 Fewer conditions = faster approval</li>
                        </ul>
                        <p class="warning-note">\u26A0\uFE0F Keep in mind: Turn-key approvals usually expire after 12 months \u2014 let's get it right from the start!</p>
                    </div>
                </div>
                
                <div class="cta-block">
                    <h5 class="section-heading">\u{1F4AC} Let's Talk Over Coffee</h5>
                    <p class="cta-text">Let me show you how you can do.</p>
                    <ul class="benefits-list compact">
                        <li class="benefit-item">\u2705 Custom finance solutions</li>
                        <li class="benefit-item">\u2705 Support from start to finish</li>
                    </ul>
                    <p class="cta-action">\u{1F4DE} Call or message me today and let's get building!</p>
                </div>
            </div>

            <style>
            .construction-loans.compact {
                line-height: 1.4;
                padding: 1rem;
                font-family: Arial, sans-serif;
                color: #333;
                max-width: 800px;
                margin: 0 auto;
            }

            .compact .service-title {
                font-size: 1.3rem;
                color: #2a6496;
                margin-bottom: 0.5rem;
            }

            .compact .service-subtitle {
                font-weight: bold;
                margin-bottom: 1rem;
                color: #555;
            }

            .compact .service-intro {
                margin-bottom: 1rem;
            }

            .compact .section-heading {
                font-size: 1.1rem;
                color: #2a6496;
                margin: 1rem 0 0.5rem;
            }

            .compact .benefits-list {
                list-style: none;
                padding-left: 0;
                margin: 0.8rem 0;
            }

            .compact .benefit-item {
                margin-bottom: 0.5rem;
                padding-left: 1.5rem;
                position: relative;
            }

            .compact .warning-note {
                font-style: italic;
                color: #d35400;
                margin: 0.8rem 0;
            }

            .compact .cta-text {
                margin-bottom: 0.8rem;
            }

            .compact .cta-action {
                font-weight: bold;
                color: #2a6496;
                margin-top: 0.5rem;
            }

            .loan-block,
            .land-block,
            .turnkey-block {
                margin-bottom: 1.2rem;
            }
            #construction {
                scroll-margin-top: 15vh;
            }
            </style>`,
    image: {
      srcLocal: "constructionLoan",
      alt: "hero section image",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    switchPlaces: true,
    title: `<span id="investment">\u{1F4C8} Investment Properties</span>`,
    paragraph: `<div class="service-section investment-property compact">
                    <h5 class="service-title">\u{1F3E0} Investment Property & Rentals</h5>
                    <p class="service-subtitle">Looking to buy a rental or investment property? I can help.</p>
                    
                    <p class="service-intro">Right now, banks usually require a 30% deposit for investment properties (they'll lend up to 70%). But that doesn't mean you need to come up with the deposit in cash.</p>
                    
                    <div class="benefits-block">
                        <h5 class="section-heading">Here's how I can help:</h5>
                        <ul class="benefits-list">
                            <li class="benefit-item">\u2705 I'll review your current properties to see if you can use existing equity \u2014 without using your own money.</li>
                            <li class="benefit-item">\u2705 I'll structure the loan to avoid cross-collateralisation, so your properties stay as separate as possible.</li>
                            <li class="benefit-item">\u2705 I'll make sure the bank only takes as much security as they actually need \u2014 no more.</li>
                        </ul>
                    </div>
                    
                    <div class="cta-block">
                        <p class="cta-text">Let's make it easy.</p>
                        <p class="cta-question">Want to chat about how you can grow your investment portfolio without stress?</p>
                        <p class="cta-action">Let's meet for a coffee \u2014 just enter your details below and I'll be in touch!</p>
                    </div>
                </div>

                <style>
                .investment-property.compact {
                    line-height: 1.4;
                    padding: 1rem;
                    font-family: Arial, sans-serif;
                    color: #333;
                    max-width: 800px;
                    margin: 0 auto;
                }

                .compact .service-title {
                    font-size: 1.3rem;
                    color: #2a6496;
                    margin-bottom: 0.5rem;
                }

                .compact .service-subtitle {
                    font-weight: bold;
                    margin-bottom: 1rem;
                    color: #555;
                }

                .compact .service-intro {
                    margin-bottom: 1rem;
                }

                .compact .section-heading {
                    font-size: 1.1rem;
                    color: #2a6496;
                    margin: 1rem 0 0.5rem;
                }

                .compact .benefits-list {
                    list-style: none;
                    padding-left: 0;
                    margin: 0.8rem 0;
                }

                .compact .benefit-item {
                    margin-bottom: 0.5rem;
                    padding-left: 1.5rem;
                    position: relative;
                }

                .compact .cta-text {
                    font-weight: bold;
                    margin: 1rem 0 0.5rem;
                }

                .compact .cta-question {
                    margin-bottom: 0.5rem;
                    font-style: italic;
                }

                .compact .cta-action {
                    font-weight: bold;
                    color: #2a6496;
                    margin-top: 0.5rem;
                }
                #investment {
                   scroll-margin-top: 15vh;
                }
                </style>`,
    image: {
      srcLocal: "investment",
      alt: "hero section image",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    title: `<span id="bridging">\u{1F309}Bridging Loans Made Easy</span>`,
    paragraph: `
                <div class="service-section bridging-loan compact">
                    <h5 class="service-title"> Want to buy before you sell?</h5>
                    <p class="service-intro">A bridging loan can help you secure your next home before your current one is sold.</p>
                    
                    <div class="explanation-block">
                        <h5 class="section-heading">What is a Bridging Loan?</h5>
                        <p>It's a short-term loan that "bridges the gap" between buying your new home and selling your current one. Your lender will take security over both properties until the process is complete.</p>
                        <ul class="benefits-list">
                            <li class="benefit-item">\u2705 Interest-only repayments during the bridging period</li>
                            <li class="benefit-item">\u2705 Access up to 100% of your new property's value (plus fees)</li>
                            <li class="benefit-item">\u2705 Capitalise the interest so you don't make repayments until your current home sells</li>
                        </ul>
                    </div>
                    
                    <div class="benefits-block">
                        <h5 class="section-heading">Why Consider It?</h5>
                        <ul class="benefits-list">
                            <li class="benefit-item">\u{1F3E1} You can move quickly on a new home</li>
                            <li class="benefit-item">\u{1F6E0}\uFE0F Build your dream home while living in your current one</li>
                            <li class="benefit-item">\u23F3 Up to 6 months to sell (or 12 months if you're building)</li>
                            <li class="benefit-item">\u{1F4A1} Loan automatically switches to a standard mortgage after sale</li>
                        </ul>
                    </div>
                    
                    <div class="considerations-block">
                        <h5 class="section-heading">Key Things to Think About</h5>
                        <ul class="considerations-list">
                            <li class="consideration-item">Do you have an offer on your current home?</li>
                            <li class="consideration-item">Are you buying or building?</li>
                            <li class="consideration-item">Will you live in the new property or rent it out?</li>
                            <li class="consideration-item">Can you afford to service both loans during the transition?</li>
                        </ul>
                        <p class="reassurance">Let's work out the best fit for you and minimise risk.</p>
                    </div>
                    
                    <div class="capitalised-block">
                        <h5 class="section-heading">Capitalised Interest Bridging Loans</h5>
                        <ul class="benefits-list">
                            <li class="benefit-item">\u2714 No repayments on the new loan during the transition</li>
                            <li class="benefit-item">\u2714 Interest builds into your loan instead of being paid monthly</li>
                            <li class="benefit-item">\u2714 Gives you breathing room to sell at the right time</li>
                        </ul>
                    </div>
                    
                    <div class="cta-block">
                        <h5 class="section-heading">Let's Talk</h5>
                        <p class="cta-text">If you're exploring your next move and want a smooth transition, let's meet for a coffee and chat about how I can help.</p>
                    </div>
                </div>

                <style>
                .bridging-loan.compact {
                    line-height: 1.4;
                    padding: 1rem;
                    font-family: Arial, sans-serif;
                    color: #333;
                    max-width: 800px;
                    margin: 0 auto;
                }

                .compact .service-title {
                    font-size: 1.3rem;
                    color: #2a6496;
                    margin-bottom: 0.5rem;
                }

                .compact .service-intro {
                    margin-bottom: 1rem;
                }

                .compact .section-heading {
                    font-size: 1.1rem;
                    color: #2a6496;
                    margin: 1rem 0 0.5rem;
                }

                .compact .benefits-list,
                .compact .considerations-list {
                    list-style: none;
                    padding-left: 0;
                    margin: 0.8rem 0;
                }

                .compact .benefit-item,
                .compact .consideration-item {
                    margin-bottom: 0.5rem;
                    padding-left: 1.5rem;
                    position: relative;
                }

                .compact .reassurance {
                    font-style: italic;
                    margin: 0.8rem 0;
                }

                .compact .cta-text {
                    margin-bottom: 0.5rem;
                }
                #bridging {
                    scroll-margin-top: 15vh;
                }
                </style>
                `,
    image: {
      srcLocal: "bridgeLoans",
      alt: "hero section image",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    switchPlaces: true,
    title: `<span id="split"> \u2702\uFE0FSplit loans</span>`,
    paragraph: `
                <div class="service-section split-loans compact">
                <h5 class="service-title">Split Loans for Separate Buyers</h5>
                <p class="service-subtitle">Own a property together\u2014keep your finances separate.</p>
                <p class="service-intro">A split loan (not to be confused with fixed/variable) lets two or more people buy a home together while keeping their loan portions, repayments, and responsibilities separate. Perfect for people in non-traditional arrangements like friends, siblings, or separated couples who want to co-own a property but maintain financial independence.</p>
                <div class="how-it-works">
                    <h5 class="section-heading">How It Works</h5>
                    <p>Each borrower takes out their own individual loan for their share of the property.</p>
                    <p>You're both on the property title, but each of you has:</p>
                    <ul class="benefits-list">
                        <li class="benefit-item">\u2714\uFE0F Your own loan</li>
                        <li class="benefit-item">\u2714\uFE0F Your own repayment schedule</li>
                        <li class="benefit-item">\u2714\uFE0F Your own interest rate (can be fixed or variable)</li>
                        <li class="benefit-item">\u2714\uFE0F Your own responsibility\u2014no joint liability</li>
                    </ul>
                </div>
                <div class="benefits-block">
                    <h5 class="section-heading">Why People Choose Split Loans</h5>
                    <ul class="benefits-list">
                        <li class="benefit-item">\u2705 Keep your finances independent</li>
                        <li class="benefit-item">\u2705 Protect your credit\u2014you're not responsible if the other person misses repayments</li>
                        <li class="benefit-item">\u2705 Flexible loan terms\u2014each person can choose what suits them</li>
                        <li class="benefit-item">\u2705 Perfect for co-buying with friends, family, or after separation</li>
                    </ul>
                </div>
                <div class="considerations-block">
                    <h5 class="section-heading">Is This Right for You?</h5>
                    <ul class="considerations-list">
                        <li class="consideration-item">Buying a home with someone you're not financially linked to</li>
                        <li class="consideration-item">Want full control over your own portion of the loan</li>
                        <li class="consideration-item">Want peace of mind that your credit and repayments are protected</li>
                    </ul>
                </div>
                <div class="cta-block">
                    <h5 class="section-heading">Let's Make It Easy</h5>
                    <p class="cta-text">If you're thinking about buying a property with someone else\u2014but want to stay financially independent, this structure might be perfect for you.</p>
                    <p class="cta-action">Let's talk it through and see if it suits your situation.</p>
                </div>
            </div>
            <style>
            .split-loans.compact {
                line-height: 1.4;
                padding: 1rem;
                font-family: Arial, sans-serif;
                color: #333;
                max-width: 800px;
                margin: 0 auto;
            }

            .compact .service-title {
                font-size: 1.3rem;
                color: #2a6496;
                margin-bottom: 0.5rem;
            }

            .compact .service-subtitle {
                font-weight: bold;
                margin-bottom: 1rem;
                color: #555;
            }

            .compact .service-intro {
                margin-bottom: 1rem;
            }

            .compact .section-heading {
                font-size: 1.1rem;
                color: #2a6496;
                margin: 1rem 0 0.5rem;
            }

            .compact .benefits-list,
            .compact .considerations-list {
                list-style: none;
                padding-left: 0;
                margin: 0.8rem 0;
            }

            .compact .benefit-item,
            .compact .consideration-item {
                margin-bottom: 0.5rem;
                padding-left: 1.5rem;
                position: relative;
            }

            .compact .consideration-item::before {
                content: "\u2022";
                color: #2a6496;
                font-weight: bold;
                display: inline-block;
                width: 1em;
                margin-left: -1em;
            }

            .compact .cta-text {
                margin-bottom: 0.5rem;
            }

            .compact .cta-action {
                font-weight: bold;
                color: #2a6496;
                margin-top: 0.5rem;
            }
            #split {
                scroll-margin-top: 15vh;
            }
            </style>
            `,
    image: {
      srcLocal: "splitLoan",
      alt: "hero section image",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    title: `<span id="referrals">\u{1F6E1}\uFE0F Referrals</span>`,
    paragraph: `
                <div class="service-section referral-partners compact">
                    <h5 class="service-title">\u{1F91D} What Else Can I Help You With?</h5>
                    
                    <p class="service-intro">To make your journey easier, I can connect you with trusted referral partners for a range of helpful services. While I can introduce you, I'm unable to provide advice on their specific products or assess their suitability for your personal needs. You're welcome to explore these providers or choose others that best fit your situation.</p>
                    
                    <div class="partners-block">
                        <h5 class="section-heading">Services available through my referral partners:</h5>
                        <ul class="partners-list">
                            <li class="partner-item">\u{1F3E0} Tower \u2013 Fire & General Insurance</li>
                            <li class="partner-item">\u{1F512} Initio \u2013 Fire & General Insurance</li>
                            <li class="partner-item">\u{1F697} Asset Finance \u2013 For vehicles, equipment, and more</li>
                            <li class="partner-item">\u{1F4BC} K\u014Dura Wealth \u2013 KiwiSaver & Investment advice</li>
                            <li class="partner-item">\u{1F4B0} UK Pension Transfers \u2013 Bringing your pension to NZ</li>
                            <li class="partner-item">\u{1F4B1} XE Money \u2013 International money transfers</li>
                            <li class="partner-item">\u26A1 FastConnect \u2013 Utility connection services for your move</li>
                        </ul>
                    </div>
                </div>

            <style>
            .referral-partners.compact {
                line-height: 1.4;
                padding: 1rem;
                font-family: Arial, sans-serif;
                color: #333;
                max-width: 800px;
                margin: 0 auto;
            }

            .compact .service-title {
                font-size: 1.3rem;
                color: #2a6496;
                margin-bottom: 0.8rem;
            }

            .compact .service-intro {
                margin-bottom: 1.2rem;
            }

            .compact .section-heading {
                font-size: 1.1rem;
                color: #2a6496;
                margin: 1rem 0 0.8rem;
            }

            .compact .partners-list {
                list-style: none;
                padding-left: 0;
                margin: 0.8rem 0;
            }

            .compact .partner-item {
                margin-bottom: 0.6rem;
                padding-left: 1.8rem;
                position: relative;
                line-height: 1.5;
            }

            .compact .partner-item::before {
                content: "\u2022";
                color: #2a6496;
                font-weight: bold;
                display: inline-block;
                width: 1em;
                margin-left: -1em;
                position: absolute;
                left: 0;
            }
            #referrals {
                scroll-margin-top: 15vh;
            }
            </style>
            `,
    image: {
      srcLocal: "referral",
      alt: "hero section image",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Contact", Contact, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Contact", "client:component-export": "Contact" })} </main> ` })}`;
}, "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/pages/offers.astro", void 0);

const $$file$2 = "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/pages/offers.astro";
const $$url$2 = "/offers/";

const offers = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Offers,
  file: $$file$2,
  url: $$url$2
}, Symbol.toStringTag, { value: 'Module' }));

const $$Astro$1 = createAstro("https://lgwen994.github.io");
const $$Privacy = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Privacy;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Agency Aestro", "description": "YOUR META DESCRIPTION FOR SEO" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "ContentSection", ContentSection, { "style": {
    maxWidth: "800px",
    margin: "0 auto"
  } }, { "default": ($$result3) => renderTemplate` <h2>Privacy Policy</h2> <h3>1. Our Commitment to Protect Your Privacy</h3> <p>
We understand how important it is to protect your personal
                information. This document outlines our commitment to protecting
                the personal information we hold about you and explains what we
                do with that information.
</p> <p>
It is important to us that you feel confident your personal
                information is treated in a way that ensures its protection.
</p> <p>
We are committed to complying with the Privacy Principles set
                out in the Privacy Act 2020 (or any successor legislation) and
                all other applicable laws. This Privacy Policy applies in
                addition to, and does not limit, our rights and obligations
                under the Privacy Act and other applicable laws.
</p> <h3>2. Who We Are</h3> <p>
References in this Privacy Policy to "we," "us," and "our" refer
                to AQ Mortgages, Mihali Enterprises Limited, trading as Bozinoff
                Mortgages acting through a Financial Adviser.
</p> <h3>3. Your Authorisation</h3> <p>
By providing us with personal information, engaging our
                services, or using our website, you consent to the collection,
                use, storage, and disclosure of your personal information in
                accordance with this Privacy Policy.
</p> <h3>4. Changes to Our Privacy Policy</h3> <p>
We may update this Privacy Policy from time to time by
                publishing an updated version on this page. Updates will reflect
                changes in law or our business operations and will not
                disadvantage you. By continuing to engage us or use our website,
                you agree to the updated Privacy Policy.
</p> <h3>5. What Personal Information Do We Collect?</h3> <p>
Personal information refers to data that identifies or could
                identify you. This may include your name, date of birth,
                address, contact details, bank account details, and occupation.
</p> <p>
If you engage us to provide services, we may also collect
                information about your financial situation and goals to
                recommend mortgage and insurance products ("Products") that we
                are authorised to advise on.
</p> <h3>6. Why Do We Collect Your Personal Information?</h3> <p>
We collect your personal information for purposes related to our
                services and our relationship with you. This includes:
</p> <ul> <li>Responding to your enquiries;</li> <li>
Providing our services, including recommending suitable
                    Products;
</li> <li>
Sending communications and direct marketing about services
                    and products we believe may interest you (via mail, phone,
                    email, or SMS);
</li> <li>Conducting market research; and</li> <li>
Any other purpose authorised by you or permitted by the
                    Privacy Act.
</li> </ul> <p>
If you prefer not to receive marketing communications, you may
                opt out at any time by contacting us.
</p> <p>
We may also collect credit and health information on behalf of
                lenders, insurers, and other Product Providers. Each Product
                Provider has its own privacy policy which applies to information
                we collect on their behalf.
</p> <h3>7. How Do We Collect Your Personal Information?</h3> <p>
We usually collect your personal information directly from
                you—via our website, forms, emails, and phone conversations. We
                may also collect personal information from:
</p> <ul> <li>
NZ Financial Services Group Limited (NZFSG) and related
                    entities;
</li> <li>Credit reporting agencies;</li> <li>
With your permission, banks (e.g., through illion Bank
                    Statements) and employers;
</li> <li>
Product Providers, including during the term of any loan or
                    insurance product arranged by us;
</li> <li>Any other person authorised by you or the Privacy Act.</li> </ul> <p>
If you provide us with someone else's personal information, you
                confirm that:
</p> <ul> <li>
They have authorised the disclosure and the use of their
                    personal information in accordance with this policy; and
</li> <li>
They have been informed of their right to access and request
                    correction of their information.
</li> </ul> <h3>8. Updating Your Personal Information</h3> <p>
We rely on you to ensure that the information we hold about you
                is accurate and up to date. Please notify us as soon as possible
                if your details change.
</p> <h3>9. Who Do We Disclose Your Personal Information To?</h3> <p>
We may share your personal information with the following
                parties, where necessary, for the purposes outlined in Section
                6:
</p> <ul> <li>NZFSG and its related entities;</li> <li>
Product Providers, prospective lenders, mortgage insurers,
                    guarantors, trustees, and assignees;
</li> <li>Our referral partners;</li> <li>Service providers and contractors;</li> <li>
Investors or entities with an interest in our business, or
                    to whom we may transfer rights or obligations;
</li> <li>
Government agencies or regulators, where legally required;
</li> <li>Auditors (e.g., NZFSG) to ensure regulatory compliance;</li> <li>
Employers, referees, credit reporting, and identity
                    verification agencies;
</li> <li>Any other person authorised by you or by law.</li> </ul> <p>
Credit reporting agencies may hold and use your credit
                information to offer their services and may disclose this
                information to their customers.
</p> <p>
Before disclosing your personal information, we will take
                reasonable steps to ensure the recipient has similar privacy
                protections in place.
</p> <h3>
10. Do We Disclose Your Personal Information Outside New
                Zealand?
</h3> <p>
Yes, we may use cloud-based services and IT infrastructure
                located overseas to store your personal information. We may also
                share data with NZFSG and other third-party providers based
                overseas, as needed.
</p> <h3>11. Our Website</h3> <h4>Cookies and IP Addresses</h4> <p>
We may use cookies to improve your experience on our website.
                Cookies allow us to recognise your device and understand your
                use of our website, such as pages visited, time spent, and your
                browser and device type.
</p> <p>
While cookies do not collect personal information, if you submit
                your name or email address, we may link it to cookie data. You
                can disable cookies via your browser settings.
</p> <h4>Security</h4> <p>
We cannot guarantee the security of information transmitted over
                the internet. You transmit information to us at your own risk.
</p> <h4>Links to Third Parties</h4> <p>
Our website may contain links or advertisements from third
                parties. We are not responsible for the privacy practices or
                content of third-party websites or advertising networks.
</p> <h3>12. Are You Required to Provide Personal Information?</h3> <p>
No, but if you choose not to, we may not be able to provide our
                services or assist with obtaining finance or insurance.
</p> <p>
Where lawful and practical, you may interact with us anonymously
                (e.g., general enquiries), but we may be limited in how we can
                assist you.
</p> <h3>13. Access and Correction</h3> <p>
You may request access to or correction of your personal
                information at any time by contacting us. We may charge a
                reasonable fee to cover the cost of retrieving and providing
                this information.
</p> <h3>14. Further Information</h3> <p>
If you have any questions about this Privacy Policy or your
                personal information, please contact us.
</p> <p class="last-updated">Last Updated: March 2021</p> ` })} </main> ` })}`;
}, "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/pages/privacy.astro", void 0);

const $$file$1 = "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/pages/privacy.astro";
const $$url$1 = "/privacy/";

const privacy = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Privacy,
  file: $$file$1,
  url: $$url$1
}, Symbol.toStringTag, { value: 'Module' }));

const robotsTxt = `
User-agent: *
Allow: /

Sitemap: ${new URL("sitemap-index.xml", "https://lgwen994.github.io").href}
`.trim();
const GET = () => {
  return new Response(robotsTxt, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8"
    }
  });
};

const robots_txt = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET
}, Symbol.toStringTag, { value: 'Module' }));

const LogosSliderStyled = styled.section`
    padding: 0;

    ${MediaQuery.max("lg")} {
        padding: 50px 0 0;
    }

    h2 {
        margin-bottom: 50px;
    }

    .swiper .swiper-slide {
        width: calc(100% / 8);

        ${MediaQuery.max("xl")} {
            width: calc(100% / 6);
        }

        ${MediaQuery.max("lg")} {
            width: calc(100% / 4);
        }

        ${MediaQuery.max("md")} {
            width: calc(100% / 3);
        }
    }
`;
const Logo = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;

    img {
        width: 100px;
        height: 100px;
        object-fit: contain;

        [data-theme="dark"] & {
            filter: invert(1);
        }
    }
`;

const LogosSliderData = [
  {
    logo: IconSplitLoan,
    alt: "astro.build"
  },
  {
    logo: IconInstagram,
    alt: "astro.build"
  },
  {
    logo: IconFacebook,
    alt: "astro.build"
  },
  {
    logo: IconTwitter,
    alt: "astro.build"
  },
  {
    logo: IconLinkedIn,
    alt: "astro.build"
  },
  {
    logo: IconBozinoff,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  }
];

const SwiperStyled = styled(Swiper)`
    overflow: hidden;
    width: 100%;

    .swiper-wrapper {
        transition-timing-function: linear;

        display: flex;
    }

    /**
     * to customize the slider sizes, use breakpoints in swiper
     * if slidesPerView is set to auto, it will automatically adjust the size of the slides
     * to override the default size, use the following css
     * @example 
     * .swiper-slide {
     *     width: calc(100% / number);
     * }
     * live example on  LogosSlider component
    */
    .swiper-slide {
        width: calc(100% / 4);
    }
`;

const SwiperSlider = ({
  children,
  options,
  modules,
  ...rest
}) => {
  if (!children) {
    return null;
  }
  const memoChildren = useMemo(
    () => React.Children.map(children, (child, index) => /* @__PURE__ */ jsx(SwiperSlide, { className: "splide__slide", children: child }, index)),
    [children]
  );
  return /* @__PURE__ */ jsx(
    SwiperStyled,
    {
      modules,
      slidesPerView: 3,
      speed: 4e3,
      spaceBetween: 30,
      ...options,
      ...rest,
      children: memoChildren
    }
  );
};

const LogosSlider = () => {
  const data = LogosSliderData;
  if (!data || data.length === 0) {
    return null;
  }
  const slides = data.map((slide, index) => /* @__PURE__ */ jsx(Logo, { children: /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsx(
    Image,
    {
      src: slide.logo.src,
      width: slide.logo.width,
      height: slide.logo.height,
      alt: slide.alt
    }
  ) }) }, index));
  return /* @__PURE__ */ jsx(LogosSliderStyled, { children: /* @__PURE__ */ jsx(
    SwiperSlider,
    {
      modules: [Autoplay],
      options: {
        slidesPerView: "auto",
        loop: true,
        freeMode: true,
        autoplay: {
          delay: 0,
          disableOnInteraction: false
        }
      },
      children: slides
    }
  ) });
};

const LeadTextsStyled = styled.section`
    padding: 100px 0;

    ${MediaQuery.max("lg")} {
        padding: 60px 0;
    }
`;
styled.h2`
    &:last-child {
        margin-bottom: 40px;
    }
`;
const LeadTextsContent = styled.div`
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 50px;

    ${MediaQuery.max("lg")} {
        grid-template-columns: 1fr;
    }
`;
const LeadTextsContentText = styled.div`
    display: flex;
    flex-direction: column;
    gap: 150px;

    ${MediaQuery.max("lg")} {
        order: 2;
        gap: 50px;
    }

    h3 {
        font-size: 30px;
        font-weight: 200;

        ${MediaQuery.max("lg")} {
            font-size: 20px;
        }
    }

    h4 {
        font-size: 20px;

        margin-bottom: 5px;

        ${MediaQuery.max("lg")} {
            font-size: 16px;
        }
    }

    p {
        font-size: 16px;
        line-height: 1.7;
        letter-spacing: 0.7px;

        &:not(:last-child) {
            margin-bottom: 40px;
        }
    }

    > div:not(:last-child) {
        ${MediaQuery.max("lg")} {
            border-bottom: 1px solid ${Theme.tertiary};
            padding-bottom: 50px;
            margin-bottom: 0;
        }
    }
`;
const LeadTextsContentTitle = styled.div`
    display: flex;
    justify-content: center;

    > div h2 {
        position: sticky;
        top: 50%;
        display: block;
    }

    img {
        border-radius: 10px;

        border-top-right-radius: 200px;
        border-bottom-left-radius: 200px;

        width: 90%;

        ${MediaQuery.max("lg")} {
            width: 100%;
            max-height: 300px;

            border-top-right-radius: 100px;
            border-bottom-left-radius: 100px;
        }
    }
`;
styled.div`
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
    margin: 50px 0;

    ${MediaQuery.max("sm")} {
        grid-template-columns: 1fr;
    }
`;
styled.section`
    padding: 100px 0;

    ${MediaQuery.max("lg")} {
        padding: 60px 0;
    }

    h2 br {
        ${MediaQuery.max("sm")} {
            display: none;
        }
    }
`;
styled.div`
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 30px;

    ${MediaQuery.max("lg")} {
        grid-template-columns: repeat(2, 1fr);
    }

    ${MediaQuery.max("sm")} {
        grid-template-columns: 1fr;
    }
`;

const LeadTexts = ({ contentText, title }) => {
  if (!contentText && !title) {
    return null;
  }
  return /* @__PURE__ */ jsx(LeadTextsStyled, { children: /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsxs(LeadTextsContent, { children: [
    title && /* @__PURE__ */ jsx(LeadTextsContentTitle, { children: /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsx(
      "h2",
      {
        dangerouslySetInnerHTML: { __html: title }
      }
    ) }) }),
    /* @__PURE__ */ jsx(LeadTextsContentText, { children: contentText.map((content, index) => {
      return /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsx(
        "div",
        {
          dangerouslySetInnerHTML: {
            __html: content.content
          }
        }
      ) }, index);
    }) })
  ] }) }) });
};

const $$Astro = createAstro("https://lgwen994.github.io");
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Agency Aestro", "description": "YOUR META DESCRIPTION FOR SEO" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    title: `Guiding You Home with Expert Mortgage Advice`,
    paragraph: `Whether you're buying your first home, building, upgrading, refinancing, refixing, or expanding your investment portfolio, I can provide the knowledge and advice to guide you through the process.`,
    buttons: [
      {
        link: "/contact",
        text: "Book a Free Consultation",
        variant: "secondary"
      },
      {
        link: "/contact",
        text: "contact us",
        variant: "primary"
      }
    ],
    image: {
      srcLocal: "aqImg",
      alt: "hero section image",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "LogosSlider", LogosSlider, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/LogosSlider", "client:component-export": "LogosSlider" })} ${renderComponent($$result2, "ContentSection", ContentSection, { "style": {
    maxWidth: "600px",
    margin: "0 auto"
  } }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h2>Why choose us?</h2> <p>
lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed
                    do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                    ullamco
</p> ` })} ` })} ${renderComponent($$result2, "BoxOffers", BoxOffers, { "client:load": true, "boxes": [
    {
      content: `
                    <h2>+940 clients</h2>
                    <p>lorem ipsum dolor sit amet, conse dolor sit amet, conse</p>
                `
    },
    {
      content: `
                    <h2>+1000 projects</h2>
                    <p>lorem ipsum dolor sit amet, conse dolor sit amet, conse lorem ipsum dolor sit amet, conse dolor sit amet, conse</p>
                `
    },
    {
      content: `
                    <h2>10 years experience</h2>
                    <p>lorem ipsum dolor sit amet, conse dolor sit amet, conse</p>
                `
    }
  ], "client:component-hydration": "load", "client:component-path": "@modules/BoxOffers", "client:component-export": "BoxOffers" })} ${renderComponent($$result2, "LeadTexts", LeadTexts, { "client:load": true, "title": "We offer", "contentText": [
    {
      content: `
                <h3>
                    <a href=/offers#firsthome><b>First Home Buyers</b></a> - lorem ipsum dolor sit ame lorem ipsum dolor sit ame
                </h3>
            `
    },
    {
      content: `
                <h3>
                 <a href=/offers#refinancing><b>Refinancing & Refixing</b></a> - lorem ipsum dolor sit m dolor sitm dolor sit ame lorem ipsum dolor sit ame
                </h3>
                `
    },
    {
      content: `
                <h3>
                    <a href=/offers#construction><b>Construction Loans</b></a> - lorem ipsum dolor sit m dolor sitm dolor
                </h3>
                `
    },
    {
      content: `
                <h3>
                    <a href=/offers#investment><b>Investment Property & Rentals</b></a> - lorem ipsum dolor sit m dolor sitm dolor
                </h3>
            `
    },
    {
      content: `
                <h3>
                    <a href=/offers#bridging><b>Bridging Loans Made Easy</b></a> - lorem ipsum dolor sit m dolor sitm dolor
                </h3>
            `
    },
    {
      content: `
                <h3>
                    <a href=/offers#split><b>Split loans</b></a> - lorem ipsum dolor sit m dolor sitm dolor
                </h3>
            `
    },
    {
      content: `
                <h3>
                    <a href=/offers#referrals><b>Referrals</b></a> - lorem ipsum dolor sit m dolor sitm dolor
                </h3>
                `
    }
  ], "client:component-hydration": "load", "client:component-path": "@modules/LeadTexts", "client:component-export": "LeadTexts" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    switchPlaces: true,
    title: `Our Agency help with lorem`,
    paragraph: `lorem ipsum dolor sit amet, conse dolor sit amet, conse`,
    image: {
      srcLocal: "heroImg",
      alt: "hero section image",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "ContentSection", ContentSection, {}, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <figure> ${renderComponent($$result4, "Image", Image, { "srcLocal": "banks", "alt": "banks" })} </figure> ` })} ` })} </main> ` })}`;
}, "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/pages/index.astro", void 0);

const $$file = "D:/works/projects/bozinoff-mortgages/astro/agency-aestro/src/pages/index.astro";
const $$url = "";

const index = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

export { _404 as _, about as a, contact as c, index as i, offers as o, privacy as p, robots_txt as r };
