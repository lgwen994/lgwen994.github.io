import { IconAstro } from "@static/icons";
export const LogosSliderData = [
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
    {
        logo: IconAstro,
        alt: "astro.build",
    },
];
